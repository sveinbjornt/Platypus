#!/bin/sh

./AppPackageBuildScript.sh
./AppSourceBuildScript.sh
