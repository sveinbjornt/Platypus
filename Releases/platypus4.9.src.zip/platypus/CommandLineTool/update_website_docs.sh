#!/bin/sh

#scp platypus.man.pdf root@sveinbjorn.org:/www/sveinbjorn/html/files/manpages/platypus.man.pdf
scp platypus.man.html root@sveinbjorn.org:/www/sveinbjorn/html/files/manpages/platypus.man.html
