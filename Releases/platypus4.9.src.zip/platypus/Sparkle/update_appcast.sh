#!/bin/sh

scp PlatypusAppcast.xml root@sveinbjorn.org:/www/sveinbjorn/html/files/appcasts/PlatypusAppcast.xml
