#!/usr/bin/perl

use Shell;

$appPath = $ARGV[0];
$appName = $ARGV[1];
$scriptPath = $ARGV[2];
$execPath = $ARGV[3];
$iconPath = $ARGV[4];
$output = $ARGV[5];
$interpreter = $ARGV[6];
$authorized = $ARGV[7];
$platResPath = $ARGV[8];
$droppable = $ARGV[9];

$appLoc = "$appPath/$appName.app";

#print "Apploc: $appLoc\n";
#print "ExecPath: $execPath\n";

mkdir($appLoc);
mkdir("$appLoc/Contents");
mkdir("$appLoc/Contents/MacOS");
mkdir("$appLoc/Contents/Resources");

########### Copy relevant files over to new app bundle ##############

#print "Copying executable\n";
$cmd ="cp '$execPath' '$appLoc/Contents/MacOS/$appName'";
system($cmd);

#print "Copying script\n";
$cmd ="cp '$scriptPath' '$appLoc/Contents/Resources/script'";
system($cmd);

#print "Copying icon\n";
$cmd ="cp '$iconPath' '$appLoc/Contents/Resources/appIcon.icns'";
system($cmd);


#print "Output is: $output\n";

########### Generate text file containing output type ##############
### And of course, copy those nib files needed #####################
if ($output eq 0)
{
	#print "Copying menu bar nib file";
	$cmd ="cp -R '$platResPath/MenuBar.nib' '$appLoc/Contents/Resources/MenuBar.nib'";
	system($cmd);
	open(FILE, "+>$appLoc/Contents/Resources/outputType");
	print FILE "None";
	close(FILE);
}
# Progress Bar output
elsif ($output eq 1)
{
	#print "Copying menu bar nib file";
	$cmd ="cp -R '$platResPath/MenuBar.nib' '$appLoc/Contents/Resources/MenuBar.nib'";
	system($cmd);
	
	#print "Copying progress window nib file";
	$cmd ="cp -R '$platResPath/ProgressWindow.nib' '$appLoc/Contents/Resources/ProgressWindow.nib'";
	system($cmd);

	open(FILE, "+>$appLoc/Contents/Resources/outputType");
	print FILE "ProgressBar";
	close(FILE);
}
# Text output
#elsif ($output eq 2)
#{
#	cp("-R", "$iconPath/ProgressWindow.nib", "$appLoc/Contents/Resources/ProgressWindow.nib");
#}

########### Generate text file containing interpreter ##############

open(FILE, "+>$appLoc/Contents/Resources/interpreter");
print FILE $interpreter;
close(FILE);


########### Generate text file containing authority required type ##############

open(FILE, "+>$appLoc/Contents/Resources/auth");
if ($authorized eq "1")
{
	print FILE "Auth";
}
else
{
	print FILE "NoAuth"
}
close(FILE);

####  Create 'droppable' file, which tells application whether it accepts dropped files ####
open(FILE, "+>$appLoc/Contents/Resources/droppable");
if ($droppable eq "1")
{   
    print FILE "drop"
}
else
{
    print FILE "noDrop"
}
close(FILE);


########### Create Info.plist ##############

open(FILE, "+>$appLoc/Contents/Info.plist");
print FILE <<"EOF";
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple Computer//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>CFBundleDevelopmentRegion</key>
	<string>English</string>
EOF


if ($droppable eq "1")
{
print FILE <<"EOF";
<key>CFBundleDocumentTypes</key>
<array>
	<dict>
		<key>CFBundleTypeExtensions</key>
		<array>
			<string>*</string>
		</array>
		<key>CFBundleTypeMIMETypes</key>
		<array>
			<string>*</string>
		</array>
		<key>CFBundleTypeRole</key>
		<string>Viewer</string>
	</dict>
</array>
EOF
}

print FILE <<"EOF";
	<key>CFBundleExecutable</key>
	<string>$appName</string>
	<key>CFBundleIconFile</key>
	<string>appIcon.icns</string>
	<key>CFBundleInfoDictionaryVersion</key>
	<string>6.0</string>
	<key>CFBundlePackageType</key>
	<string>APPL</string>
	<key>CFBundleSignature</key>
	<string>????</string>
	<key>CFBundleVersion</key>
	<string>1.0</string>
	<key>CSResourcesFileMapped</key>
	<true/>
</dict>
</plist>
EOF
close(FILE);
