README document for Platypus version 1.8 21/11/2003


What is Platypus?

Platypus is a MacOS X program for creating application wrappers around scripts, i.e. creating MacOS X applications that execute a script they are bundled with. Scripts can thus be run transparently from the graphical window environment without running them manually from the command line and made to integrate seamlessly with the user interface.

Platypus is written for the Carbon Application Programming Interfaces and the source code is made available at the Platypus website (press the "Platypus Website" button in the About window to go there).  It is distributed under the terms and conditions of the Free Software Foundation's GNU General Public License which accompanied this document.


How do I use Platypus?

Using Platypus is simple enough.  You type in the name you want to assign to the application in the "App Name" field and then locate the shell script via a navigation dialog by pressing the "Select" button (or alternatively, drag the script or type in the path manually).  You can then proceed to create the application by pressing the aptly named "Create" button.  

Platypus can create applications that run script that require root ("Administrator") privileges.  In order for a script to be able to run privileged operations, you must check the "Requires root privileges" checkbox.  

If you're interested in creating script apps that accept dropped files as argument you can check the "Droppable" box.  The dropped files are then passed to script as arguments in the @ARGV array.  

If you don't set the 'Droppable' checkbox, your script will receive the path to the folder containing the application (minus trailing slash) as the first and only argument (i.e. $1, $ARGV[0] and so forth).  This can be very handy for creating installers or for working with paths relative to the application.  If you use Platypus to create an installer for a piece of software then please let me know :).

Platypus supports drag'n drop so it is possible to drag scripts on an open Platypus window (or the Platypus application icon) to automatically fill in the required fields.  Drag'n drop also extends to icons, so you can drop your own .icns file to get a custom icon for your app.

Due to popular demand, the interpreter for a script can now be manually defined via the Interpreter text field.  For most users, it should be sufficient to select from the list of predefined interpreters in the Script Type radio button group.  

If you want the Platypus app to display an indeterminate progress bar while executing, you must select the "Progress Bar" radio button in Output Type.  Pressing the Cancel button on the progress bar will kill the application and the script it is executing.   At present, the script process will not die on quitting if it was run with root privileges.

In the Scripts folder you'll find a number of sample scripts demonstrating the kind of functionality that can be achieved with Platypus.  Some of them may require certain settings (i.e. droppable or root privileges), so make sure you read them over.

Applications created with Platypus will not function if there are syntax errors in the scripts.  I have neither the time nor the inclination to provide help to people who want to learn scripting.  There are plenty of good books available on the subject that would do a better job in any case.

For a short tutorial and more information about Platypus, visit http://sveinbjorn.vefsyn.is/platypus.


How does Platypus work?

Platypus creates a MacOS X application bundle that contains an executable file and the script in question.  When a Platypus app is launched, the executable file gets the script interpreter and other settings (authentication requirements, output type etc) from configuration files in the Resources folder within bundle and then executes the script according to those parameters by forking.  Please note that force-quitting Platypus apps may result in some processes continuing in the background if the application was run with root authentication.



Things that need to be done:

* Enable output of type text, i.e. open pipe to script execution and direct script output into a window
* Default in Navigation dialog to save app should be the folder containing the script
* Add passing of Platypus app path as first argument for apps that are not droppable
* Fix bug which causes Platypus to quit occasionally


Version history

21/11/2003 - Version 1.8
		* Platypus applications that don't aren't marked 'Is Droppable' now 
			- get the path of the app's enclosing folder as first argument ($1, $ARGV[0] etc.)
			- This can be very handy for installers or working with files relative to the app
			- A sample script that utilises this is included ("AppThatMovesToHomeFolder.sh")

17/11/2003 - Version 1.7

		* Platypus no longer has problems with spaces in certain paths
		* Fixed an interface bug where Platypus window would close after Create, although cancelled
		* Platypus apps with progress bar now really do have a functioning "Cancel" button
		* Fixed bug where new platypus windows retained former Droppable setting
		* Some cool sample scripts bundled with Platypus

14/08/2003 - Version 1.6

		* New option to create droppable apps that pass files as arguments to script (like DropScript)
		* Fixed a nasty bug where Platypus apps would freeze up after failed authentication
		* Platypus apps with progress bar now have a "Cancel" button
		* Minor user interface enhancements in both Platypus and Platypus-generated apps

29/07/2003 - Version 1.5 released

		* Platypus apps now remain running while root-privileged scripts finish executing
		* Invisible files and folders are now shown in Navigation dialogs
		* Navigation dialogs use newer API calls, support app names longer than 31 characters and are non-modal
		* Platypus apps can now be set to display a progress bar while running
		* Platypus apps are now threaded, which means that the interface is responsive while they're running
		* Some interface tweaks and bug fixes

18/06/2003 - Version 1.4 released

		* It is now possible to create script applications that require root privileges
		* Optimized performance and improved error handling for apps created with Platypus
		* Platypus now launches faster
		* Fixed bug where window proxy icon remained unchanged when a custom icon was set
		* Fixed bug where apps with spaces in their names failed to function
		* Platypus apps now remain running while script is executing

15/06/2003 - Version 1.3 released

		* Script interpreter can now be defined
		* Shebang line (#!) is now parsed for interpreter
		* "Open" menu item now works
		* New windows center correctly on screen
		* Code optimized and trimmed
		* Minor interface tweaks

13/06/2003 - Version 1.2 released

		* Support for Ruby, AppleScript and Tcl
		* Drag'n drop support for script path
		* Now gracefully handles files dropped on Platypus application icon
		* Better icons - specialized default icons for each script type
		* Fixed bug where application placement name in Navigation dialog was ignored when creating app

11/06/2003 - Version 1.1 released

		* Platypus no longer uses huge amounts of CPU power for window redraws
		* Text fields are now Unicode and displayed in correct font
		* Support for Perl and Python scripts
		* Drag'n drop support for script path
		* Drag'n drop support for custom app icon
		* Scripts can now be dragged on Platypus to automatically create an app in the same directory
		* Now warns about inappropriate script suffixes

09/06/2003 - Version 1.0 released


Enjoy

Sveinbjorn Thordarson
http://raunvis.hi.is/~ssv/software.html
<sveinbtNO@SPAM.hi.is>

