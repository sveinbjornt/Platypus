#!/bin/sh
#
# Creates 3 folders on your desktop.  Lame and simple, I know :).
#

mkdir ~/Desktop/Folder1
mkdir ~/Desktop/Folder2
mkdir ~/Desktop/Folder3