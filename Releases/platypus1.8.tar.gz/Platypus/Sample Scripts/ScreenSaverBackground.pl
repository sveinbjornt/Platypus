#!/usr/bin/perl
#
# This simple script is a rather cool demonstration of the power of Platypus.
# An app created with this Perl script will toggle on and off the hidden
# screen saver background feature in MacOS X.
#


use Shell;

$matched = false;

@procs = `ps -cxa`;
for $proc (@procs )
{
	if ($proc =~ /ScreenSaverEngine/)
	{
		$matched = true;
		killall("ScreenSaverEngine");
	}
}

if ($matched eq false)
{
	system("/System/Library/Frameworks/ScreenSaver.framework/Versions/A/Resources/ScreenSaverEngine.app/Contents/MacOS/ScreenSaverEngine -background &");
}
