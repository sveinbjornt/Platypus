#!/usr/bin/perl
#
# Make sure you set this Perl script as droppable.  It loops
# through the @ARGV array and gzips the files passed to it via drop.
#
# Apparently there are some security issues with Perl and @ARGV, so
# suid won't work -- hence no privileged execution.
#

use Shell; # for gzip

# loop through list of files dropped
foreach(@ARGV)
{
	# gzip each file in turn
	gzip("$_");
}