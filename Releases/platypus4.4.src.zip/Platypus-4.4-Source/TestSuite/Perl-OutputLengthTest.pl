#!/usr/bin/perl

for ($i = 0; $i < 10000; $i++)
{
    print "$i: Hello World\n";
}