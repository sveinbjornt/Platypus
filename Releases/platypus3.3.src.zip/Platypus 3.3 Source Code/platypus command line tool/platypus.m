/*
    platypus - command line equivalent to the Mac OS X Platypus application
			 - create .app wrappers around scripts
			 
    Copyright (C) 2005 Sveinbjorn Thordarson <sveinbt@hi.is>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/

/*  CHANGE LOG
        
    1.0 - * First release of the Platypus command line tool

*/


/*  TODO
        
    * Support for bundling plain binary files in an application wrapper, as opposed to just scripts
	* Support for bundling support files with script app, like Platypus permits
*/

/*
	SUPPORT FILES FOR PROGRAM

	/usr/local/share/platypus/exec			Executable bundled with app
	/usr/local/share/platypus/MainMenu.nib	Nib file for app
	/usr/local/share/platypus/icons/*		All the default icons for Platypus apps

	The location of these files can be changed by chaning #define RESOURCE_FOLDER_PATH 
	
*/

/*
	COMMAND LINE OPTIONS
	
	// *required*
	-a	Application Name
	-t	Script Type
	-o	Output Type
	
	// *advanced options*
	
	-i	Icon file
	-p	Interpreter
	-V	Version
	-s	Signature (4 character string)
	-I	Identifier

	-A	Requires Administrator privileges
	-S	Secure bundled script
	-D	Is Droppable
	-B	Runs in background
	-R  remainRunningAfterCompletion
	
	-v	Print version string
	-h	Print help
*/

///////////// IMPORTS/INCLUDES ////////////////

#import <Foundation/Foundation.h>
#import <Carbon/Carbon.h>

#import "IconFamily.h"
#import "STUtil.h"
#import "STChecksum.h"
#import "SillyStringEncrypt.h"

#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>

///////////// DEFINITIONS ////////////////

#define		PROGRAM_STAMP		"Platypus Command Line Tool-1.2" 
#define		PROGRAM_STRING  	"platypus"
#define		VERSION_STRING		"1.2"
#define		AUTHOR_STRING 		"Sveinbjorn Thordarson"
#define		OPT_STRING			"f:a:t:o:i:u:p:V:s:I:ASDBRvh" 

#define		OUTPUT_NONE			0
#define		OUTPUT_PROGRESS_BAR	1
#define		OUTPUT_TEXT_WINDOW	2

#define		SCRIPT_TYPE_SHELL		0
#define		SCRIPT_TYPE_PYTHON		1
#define		SCRIPT_TYPE_APPLESCRIPT	2
#define		SCRIPT_TYPE_EXPECT		3
#define		SCRIPT_TYPE_PERL		4
#define		SCRIPT_TYPE_RUBY		5
#define		SCRIPT_TYPE_TCL			6
#define		SCRIPT_TYPE_PHP			7

#define		RESOURCE_FOLDER_PATH	@"/usr/local/share/platypus"

///////////// PROTOTYPES ////////////////

static int CreateApplication (char *scriptPath, char *appPath);
static NSDictionary* GetInfoPropertyListDictionary (void);
static int GetResourcePaths (void);
static int GetFileTypeFromSuffix (NSString *fileName);
static NSString* GetInterpreterFromShebang (NSString *path);
static short UnixIsFolder (char *path);
static void PrintVersion (void);
static void PrintUsage (void);
static void PrintHelp (void);


///////////// GLOBALS ////////////////

BOOL	requiresAdminPrivileges = FALSE;
BOOL	secureBundledScript = FALSE;
BOOL	isDroppable = FALSE;
BOOL	runsInBackground = FALSE;
BOOL	remainRunningAfterCompletion = FALSE;

NSString	*appNameStr;
int			scriptType = -1;
NSString	*outputType; // output type defaults to "None"

NSString	*iconPathStr;
NSString	*interpreterStr;
NSString	*versionStr;
NSString	*signatureStr;
NSString	*identifierStr;
NSString	*authorStr;

// Resource paths
NSString	*execResourcePath;
NSString	*nibResourcePath;
NSArray		*iconResourcePaths;

// Bundled files
NSMutableArray		*bundledFiles;

int main (int argc, const char * argv[]) 
{
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	NSArray *defaultInterpreters = [NSArray arrayWithObjects: @"/bin/sh",@"/usr/bin/python",@"/usr/bin/osascript",@"/usr/bin/expect",@"/usr/bin/perl",@"/usr/bin/ruby",@"/usr/bin/tclsh",@"/usr/bin/php", nil];
	bundledFiles = [NSMutableArray arrayWithCapacity: 255];

	int				rc, optch, err = 0, st, i;
	char			*scriptPath, *appPath;
    static char		optstring[] = OPT_STRING;
	NSString		*dstPath;
	NSString		*theStr;

    while ( (optch = getopt(argc, (char * const *)argv, optstring)) != -1)
    {
        switch(optch)
        {
			// App Name
			case 'a':
				appNameStr = [NSString stringWithCString: optarg];
				break;
			
			case 'f':
				theStr = [NSString stringWithCString: optarg];
				[bundledFiles addObject: theStr];
				break;
			
			// Script Type
			case 't':
				theStr = [NSString stringWithCString: optarg];
				if ([theStr caseInsensitiveCompare: @"shell"] == NSOrderedSame)
					scriptType = SCRIPT_TYPE_SHELL;
				else if ([theStr caseInsensitiveCompare: @"python"] == NSOrderedSame)
					scriptType = SCRIPT_TYPE_PYTHON;
				else if ([theStr caseInsensitiveCompare: @"applescript"] == NSOrderedSame)
					scriptType = SCRIPT_TYPE_APPLESCRIPT;
				else if ([theStr caseInsensitiveCompare: @"expect"] == NSOrderedSame)
					scriptType = SCRIPT_TYPE_EXPECT;
				else if ([theStr caseInsensitiveCompare: @"perl"] == NSOrderedSame)
					scriptType = SCRIPT_TYPE_PERL;
				else if ([theStr caseInsensitiveCompare: @"ruby"] == NSOrderedSame)
					scriptType = SCRIPT_TYPE_RUBY;
				else if ([theStr caseInsensitiveCompare: @"tcl"] == NSOrderedSame)
					scriptType = SCRIPT_TYPE_TCL;
				else if ([theStr caseInsensitiveCompare: @"php"] == NSOrderedSame)
					scriptType = SCRIPT_TYPE_PHP;
				else
				{
					fprintf(stderr, "Invalid string passed as script type with -t option\n");
					fprintf(stderr, "Valid strings are: shell python applescript expect perl ruby tcl php\n");
					fprintf(stderr, "Please see man page for details\n");
					exit(1);
				}
				if (interpreterStr == NULL)//if interpreter hasn't already been set, we set it
					interpreterStr = [defaultInterpreters objectAtIndex: scriptType];
				break;
		
			// Output Type
            case 'o':
				outputType = [NSString stringWithCString: optarg];
				if ([outputType caseInsensitiveCompare: @"None"] != NSOrderedSame &&
					[outputType caseInsensitiveCompare: @"ProgressBar"] != NSOrderedSame &&
					[outputType caseInsensitiveCompare: @"TextWindow"] != NSOrderedSame)
				{
						fprintf(stderr, "Output type \"%s\" not recognized.\nSupported output types: None ProgressBar TextWindow\n", [outputType cString]);
						exit(1);
				}
				break;
			
			case 'u':
				authorStr = [NSString stringWithCString: optarg];
				break;
			case 'i':
				iconPathStr = [NSString stringWithCString: optarg];
				break;
			case 'p':
				interpreterStr = [NSString stringWithCString: optarg];
				break;
			case 'V':
				versionStr = [NSString stringWithCString: optarg];
				break;
			case 's':
				signatureStr = [NSString stringWithCString: optarg];
				if ([signatureStr length] != 4) // it must be a 4-character string
				{
					fprintf(stderr, "Signature '%s' invalid.\nA signature must consist of exactly 4 ASCII characters.\n", [signatureStr cString]);
					exit(1);
				}
				break;
			case 'I':
				identifierStr = [NSString stringWithCString: optarg];
				break;
				
            case 'A':
				requiresAdminPrivileges = TRUE;
				break;
			case 'S':
				secureBundledScript = TRUE;
				break;
			case 'D':
				isDroppable = TRUE;
				break;
			case 'B':
				runsInBackground = TRUE;
				break;
			case 'R':
				remainRunningAfterCompletion = TRUE;
				break;
			
			case 'v':
                PrintVersion();
                exit(0);
                break;
            case 'h':
                PrintHelp();
                return 0;
                break;
            default: // '?'
                rc = 1;
                PrintUsage();
                return 0;
        }
    }
	
	if (argc - optind < 2) // at least script path and application destination params must follow
    {
        fprintf(stderr,"Too few arguments.\n");
        PrintUsage();
        exit(1);
    }
	
	//get script path parameter
	(char *)scriptPath = (char *)argv[optind];
	if (scriptPath == NULL)
	{
		fprintf(stderr, "Missing parameter:  Script Path\n");
		PrintUsage();
		exit(1);
	}
	//make sure it isn't a folder
	if (UnixIsFolder(scriptPath))
	{
		fprintf(stderr, "File %s is a folder\n", scriptPath);
		PrintUsage();
		exit(1);
	}
	//make sure we can read it
	if (access(scriptPath, R_OK|F_OK) == -1)
	{
		perror(scriptPath);
		exit(errno);
	}
	
	//get application destination parameter
	(char *)appPath = (char *)argv[optind+1];
	if (appPath == NULL)
	{
		fprintf(stderr, "Missing parameter:  Application Destination Path\n");
		PrintUsage();
		exit(1);
	}
	
	// OK, no interpreter specified.  Let's try to guess.
	if (interpreterStr == NULL)
	{
		interpreterStr = GetInterpreterFromShebang([NSString stringWithCString: scriptPath]);
		if ([interpreterStr caseInsensitiveCompare: @""] == NSOrderedSame) //OK, no interpreter in Shebang line
		{
			st = GetFileTypeFromSuffix([NSString stringWithCString: scriptPath]);
			if (st == -1) // can't find interpreter in shebang or deduce from suffix...we give up
			{
				fprintf(stderr, "Unable to auto-detect script type/interpreter (set manually with -t or -p option)\n");
				exit(1);
			}
			else // we have found the script type based on the suffix
			{
				scriptType = st;
				interpreterStr = [defaultInterpreters objectAtIndex: scriptType];
			}
		}
		else //we've found the interpreter for the script in the Shebang line
		{	// let's try to see if the interpreter matches any of the preset interpreters
			for (i = 0; i < [defaultInterpreters count]; i++)
			{
				if ([interpreterStr caseInsensitiveCompare: [defaultInterpreters objectAtIndex: i]] == NSOrderedSame)
					scriptType = i;
			}
		}
	}

	err = CreateApplication(scriptPath, appPath);
	
    [pool release];
	if (err)
	{
		fprintf(stderr, "Application was not created because CreateApplication() returned error %d\n", err);
		exit(err);
    }
	return 0;
}

#pragma mark -

static int CreateApplication (char *scriptPath, char *appPath)
{
	NSString		*contentsPath, *macosPath, *resourcesPath, *lprojPath, *pkgInfoPath;
	NSFileManager	*fileManager = [NSFileManager defaultManager];
	NSString		*scriptPathStr, *appPathStr;
	BOOL			isDir;
	int				i;
	
	/////// Make sure we have the resources available to create an app /////////////////
	
	if (GetResourcePaths())//if there was a problem
	{
		fprintf(stderr, "Application could not be created because of missing resources\n");
		exit(1);
	}
	
	//make sure script path exists and is not a folder
	scriptPathStr = [NSString stringWithCString: scriptPath];
	if ([fileManager fileExistsAtPath: scriptPathStr isDirectory: &isDir] && isDir)
	{
		fprintf(stderr, "%s is a folder\n", scriptPath);
		exit(1);
	}
	
	appPathStr  = [NSString stringWithCString: (char *)appPath];
	if (![appPathStr hasSuffix: @".app"]) //make sure it has .app suffix
		appPathStr = [appPathStr stringByAppendingString:@".app"];
	//make sure there isn't already an application of same name at path
	if ([fileManager fileExistsAtPath: appPathStr])
	{
		fprintf(stderr, "The application %s already exists\n", appPath);
		exit(1);
	}

	//////// Set all those values that were unset by flags to their default values ////////
	
	if (appNameStr == NULL) //if no app name set, app name is name of script minus suffix
		appNameStr = [STUtil cutSuffix: [scriptPathStr lastPathComponent]];
	if (outputType == NULL)//if no output type, default to None
		outputType = [NSString stringWithString: @"None"];
	if (signatureStr == NULL)
		signatureStr = [NSString stringWithString: @"????"];
	if (versionStr == NULL)
		versionStr = [NSString stringWithString: @"1.0"];
	if (authorStr == NULL)
		authorStr = NSFullUserName();
	if (identifierStr == NULL)
	{	// create identifier string from user name and app name, i.e. org.username.appname
		identifierStr = [NSString stringWithFormat: @"org.%@.%@", NSUserName(), [appPathStr lastPathComponent]];
		identifierStr = [[identifierStr componentsSeparatedByString:@" "] componentsJoinedByString:@""];//no spaces
	}
	if (iconPathStr == NULL) // if no icon has been specified, we use the default for the type
	{
		if (scriptType == -1) //if it has no type set
			iconPathStr = [NSString stringWithString: @"None"];
		else //
			iconPathStr = [iconResourcePaths objectAtIndex: scriptType];
	}
	
	//////// OK, Let's start creating the application bundle //////////
	
	[fileManager createDirectoryAtPath: appPathStr attributes:nil];
	
	//Contents
	contentsPath = [appPathStr stringByAppendingString:@"/Contents"];
	[fileManager createDirectoryAtPath: contentsPath attributes:nil];
	
	//MacOS
	macosPath = [contentsPath stringByAppendingString:@"/MacOS"];
	[fileManager createDirectoryAtPath: macosPath attributes:nil];
	
	//Resources
	resourcesPath = [contentsPath stringByAppendingString:@"/Resources"];
	[fileManager createDirectoryAtPath: resourcesPath attributes:nil];
	
	//English.lproj
	lprojPath = [resourcesPath stringByAppendingString:@"/English.lproj"];
	[fileManager createDirectoryAtPath: lprojPath attributes:nil];
	
	//PkgInfo file
	pkgInfoPath = [contentsPath stringByAppendingString:@"/PkgInfo"];
	[[NSString stringWithString: [NSString stringWithFormat: @"APPL%@", signatureStr]] writeToFile: pkgInfoPath atomically: YES];

	//copy executable, nib file, script and icon to app bundle
	[fileManager copyPath: execResourcePath toPath: [macosPath stringByAppendingString:[NSString stringWithFormat: @"/%@", appNameStr]] handler:nil];
	[fileManager copyPath: nibResourcePath toPath: [lprojPath stringByAppendingString: @"/MainMenu.nib"] handler:nil];

	//create infoPlist.strings
	NSString *infoPlistStrings = [NSString stringWithFormat:
						@"CFBundleName = \"%@\";\nCFBundleShortVersionString = \"%@\";\nCFBundleGetInfoString = \"%@ version %@ Copyright %d %@\";\nNSHumanReadableCopyright = \"Copyright %d %@.\";",  
												  appNameStr, versionStr, appNameStr,versionStr, [[NSCalendarDate calendarDate] yearOfCommonEra], authorStr, [[NSCalendarDate calendarDate] yearOfCommonEra], authorStr];
	[infoPlistStrings writeToFile:  [lprojPath stringByAppendingString:@"/InfoPlist.strings"] atomically: YES];
	
	//create AppSettings.plist file
	NSMutableDictionary *appSettingsPlist = [NSMutableDictionary dictionaryWithCapacity: 40];
	[appSettingsPlist setObject: [NSNumber numberWithBool: requiresAdminPrivileges] forKey:@"RequiresAdminPrivileges"];
	[appSettingsPlist setObject: [NSNumber numberWithBool: isDroppable] forKey:@"IsDroppable"];
	[appSettingsPlist setObject: [NSNumber numberWithBool: remainRunningAfterCompletion] forKey:@"RemainRunningAfterCompletion"];
	[appSettingsPlist setObject: [NSNumber numberWithBool: secureBundledScript] forKey:@"EncryptAndChecksum"];
	if (secureBundledScript)//it is checked
		[appSettingsPlist setObject: [STChecksum getChecksumForFileAsString: scriptPathStr] forKey: @"ScriptChecksum"];
	[appSettingsPlist setObject: outputType forKey:@"OutputType"];
	[appSettingsPlist setObject: interpreterStr forKey:@"ScriptInterpreter"];
	[appSettingsPlist setObject: [NSString stringWithFormat: @"%s", PROGRAM_STAMP] forKey: @"Creator"];
	NSString *appSettingsPlistPath = [resourcesPath stringByAppendingString:@"/AppSettings.plist"];
	[appSettingsPlist writeToFile: appSettingsPlistPath atomically: YES];
	
	// create script file in app bundle
	NSString *scriptString = [NSString stringWithContentsOfFile: scriptPathStr];
	if (secureBundledScript)
	{
		[[SillyStringEncrypt sillyEncryptString: scriptString] writeToFile: [resourcesPath stringByAppendingString:@"/.script"] atomically: YES];
		[@"" writeToFile: [resourcesPath stringByAppendingString:@"/script"] atomically: YES];
	}
	else
	{
		[scriptString writeToFile: [resourcesPath stringByAppendingString:@"/script"] atomically: YES];
		[scriptString writeToFile: [resourcesPath stringByAppendingString:@"/.script"] atomically: YES];
	}
	//create icon
	if ([iconPathStr caseInsensitiveCompare: @"None"] != NSOrderedSame)// application has been specified as having no icon, or has no type set
	{
		IconFamily *iconFam = [IconFamily iconFamilyWithContentsOfFile: iconPathStr];
		if (iconFam != NULL)
			[iconFam writeToFile: [resourcesPath stringByAppendingString:@"/appIcon.icns"]];
	}
	
	//create Info.plist file
	NSDictionary *infoPlist = (NSDictionary *)GetInfoPropertyListDictionary();
	[infoPlist writeToFile: [contentsPath stringByAppendingString:@"/Info.plist"] atomically: YES];
	
	//copy bundled files over
	for (i = 0; i < [bundledFiles count]; i++)
	{
		[fileManager copyPath: [bundledFiles objectAtIndex: i] toPath: resourcesPath handler: nil];
	}
	
	return 0;
}


/*****************************************
 - Generate dictionary for Info.plist in app bundle
*****************************************/

static NSDictionary* GetInfoPropertyListDictionary (void)
{
	NSDictionary *infoPlist;
	
	if (!isDroppable)
	{
		infoPlist = [NSDictionary dictionaryWithObjectsAndKeys: 
								@"English", @"CFBundleDevelopmentRegion",
								appNameStr, @"CFBundleExecutable", 
								appNameStr, @"CFBundleName",
								[NSString stringWithFormat: @"%@ %@ Copyright %d %@", appNameStr, versionStr, [[NSCalendarDate calendarDate] yearOfCommonEra], authorStr ], @"CFBundleGetInfoString", 
								@"appIcon.icns", @"CFBundleIconFile",  
								versionStr, @"CFBundleVersion",
								versionStr, @"CFBundleShortVersionString", 
								identifierStr, @"CFBundleIdentifier",  
								[NSString stringWithFormat:@"%d", runsInBackground], @"LSUIElement",
								@"6.0", @"CFBundleInfoDictionaryVersion",
								@"APPL", @"CFBundlePackageType",
								signatureStr, @"CFBundleSignature",
								@"MainMenu", @"NSMainNibFile",  
								@"NSApplication", @"NSPrincipalClass",  nil];

	}
	else
	{	
			NSDictionary	*typesAndSuffixesDict = [NSDictionary dictionaryWithObjectsAndKeys:
								[NSArray arrayWithObject: @"*"], @"CFBundleTypeExtensions",//extensions
								[NSArray arrayWithObjects: @"****", @"fold", nil], @"CFBundleTypeOSTypes",//os types
								@"Viewer", @"CFBundleTypeRole", nil];//viewer or editor?
	
		infoPlist = [NSDictionary dictionaryWithObjectsAndKeys:
								@"English", @"CFBundleDevelopmentRegion",
								appNameStr, @"CFBundleExecutable",
								appNameStr, @"CFBundleName",
								[NSArray arrayWithObject: typesAndSuffixesDict] ,@"CFBundleDocumentTypes",
								[NSString stringWithFormat: @"%@ %@ Copyright %d %@", appNameStr, versionStr, [[NSCalendarDate calendarDate] yearOfCommonEra], authorStr ], @"CFBundleGetInfoString", 
								@"appIcon.icns", @"CFBundleIconFile",  
								versionStr, @"CFBundleVersion", 
								versionStr, @"CFBundleShortVersions", 
								identifierStr, @"CFBundleIdentifier",
								[NSString stringWithFormat:@"%d", runsInBackground], @"LSUIElement",
								@"6.0", @"CFBundleInfoDictionaryVersion",
								@"APPL", @"CFBundlePackageType",
								signatureStr, @"CFBundleSignature",
								@"MainMenu", @"NSMainNibFile",  
								@"NSApplication", @"NSPrincipalClass", nil];
	}
	return(infoPlist);
}



/****************************************
- Get paths for all resources used by program
****************************************/

static int GetResourcePaths (void)
{
	execResourcePath = [NSString stringWithFormat: @"%@/exec", RESOURCE_FOLDER_PATH]; 
	nibResourcePath = [NSString stringWithFormat: @"%@/MainMenu.nib", RESOURCE_FOLDER_PATH];
	iconResourcePaths = [NSArray arrayWithObjects:
										[NSString stringWithFormat: @"%@/icons/PlatypusDflt.icns", RESOURCE_FOLDER_PATH],
										[NSString stringWithFormat: @"%@/icons/PythonSnake.icns", RESOURCE_FOLDER_PATH],
										[NSString stringWithFormat: @"%@/icons/AppleScript.icns", RESOURCE_FOLDER_PATH],
										[NSString stringWithFormat: @"%@/icons/ExpectMonkey.icns", RESOURCE_FOLDER_PATH],
										[NSString stringWithFormat: @"%@/icons/PerlCamel.icns", RESOURCE_FOLDER_PATH],
										[NSString stringWithFormat: @"%@/icons/RubyGoat.icns", RESOURCE_FOLDER_PATH],
										[NSString stringWithFormat: @"%@/icons/TclFlamingo.icns", RESOURCE_FOLDER_PATH],
										[NSString stringWithFormat: @"%@/icons/PHPBird.icns", RESOURCE_FOLDER_PATH],
										[NSString stringWithFormat: @"%@/icons/PlatypusDroplet.icns", RESOURCE_FOLDER_PATH],
										[NSString stringWithFormat: @"%@/icons/PlatypusPlate.icns", RESOURCE_FOLDER_PATH],
										[NSString stringWithFormat: @"%@/icons/installer.icns", RESOURCE_FOLDER_PATH], nil];
	return 0;
}


/*****************************************
 - Parse the Shebang line (#!) to get the interpreter for the script
   We're doing this by getting a C string.  Apple's NSString doesn't
   seem to be any more convenient, and this seems to work just fine
*****************************************/

static NSString* GetInterpreterFromShebang (NSString *path)
{
	FILE			*file;
	static char		str[1024];
	char			filePath[1024];
	char			len,i;
	
	[path getCString: (char *)&filePath maxLength: sizeof(filePath)];
	
	//open file and read to the first newline character
	file = fopen(filePath, "r");
	fgets(str,1024,file);
	fclose(file);
	
	//doesn't seem to be a shebang line
	if (str[0] != '#' || str[1] != '!')
		return @"";
	
	//jump over the first two characters that indicate the shebang
	strcpy((char *)&str, (char *)&str[2]);
	len = strlen((char *)&str);

	for (i = 0; i < len; i++)
	{
		//terminate string with a null character when we reach a space or a newline
		if (str[i] == '\n'|| str[i] == ' ')
			(char)str[i] = NULL;
	}
	
	return [NSString stringWithCString: (char *)&str];
}

/*****************************************
 - Determine script type based on a file's suffix
*****************************************/

static int GetFileTypeFromSuffix (NSString *fileName)
{
	if ([fileName hasSuffix: @".sh"])
		return 0;
	else if ([fileName hasSuffix: @".py"])
		return 1;
	else if ([fileName hasSuffix: @".scpt"] || [fileName hasSuffix: @".applescript"])
		return 2;
	else if ([fileName hasSuffix: @".exp"] || [fileName hasSuffix: @".expect"])
		return 3;
	else if ([fileName hasSuffix: @".pl"] || [fileName hasSuffix: @".perl"])
		return 4;
	else if ([fileName hasSuffix: @".rb"] || [fileName hasSuffix: @".rbx"])
		return 5;
	else if ([fileName hasSuffix: @".tcl"])
		return 6;
	else if ([fileName hasSuffix: @".php"])
		return 7;
	else
		return -1;
}

////////////////////////////////////////
// Check if file in designated path is folder
///////////////////////////////////////
static short UnixIsFolder (char *path)
{
    struct stat filestat;
    short err;
    
    err = stat(path, &filestat);
    if (err == -1)
        return err;

    if(S_ISREG(filestat.st_mode) != 1)
        return true;
    else 
        return false;
}

#pragma mark -

////////////////////////////////////////
// Print version and author to stdout
///////////////////////////////////////

static void PrintVersion (void)
{
    printf("%s version %s by %s\n", PROGRAM_STRING, VERSION_STRING, AUTHOR_STRING);
}

////////////////////////////////////////
// Print usage string to stdout
///////////////////////////////////////

static void PrintUsage (void)
{
    printf("usage: %s [-vh] [-ASDBRuipVsIato] [script] [destination]\n", PROGRAM_STRING);
}

////////////////////////////////////////
// Print help string to stdout
///////////////////////////////////////

static void PrintHelp (void)
{
	puts("platypus - command line application wrapper generator for scripts");
	PrintVersion();
    PrintUsage();
	puts("");
	puts("Options:");
	puts("");
	puts("-a [name]		Set name of application bundle");
	puts("-t [type]		Set script type.  See man page for accepted types");
	puts("-o [type]		Set output type.  See man page for accepted types");
	puts("");
	puts("-i [icon]		Set icon for application");
	puts("-u [author]		Set name of application author");
	puts("-p [interpreter]	Set interpreter for script");
	puts("-V [version]		Set version of application");
	puts("-s [signature]		Set 4-character bundle signature");
	puts("-I [identifier]		Set bundle identifier (i.e. org.yourname.appname)");
	puts("");
	puts("-A			App requires Administrator privileges");
	puts("-S			Secure bundled script");
	puts("-D			App accepts dropped files as argument to script");
	puts("-B			App runs in background (LSUI Element)");
	puts("-R			App remains running after executing script");
	puts("");
	puts("-h			Prints help");
	puts("-v			Prints program name, version and author");
	puts("");
}


