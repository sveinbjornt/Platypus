//
//  STChecksum.h
//  Platypus
//
//  Created by Sveinbjorn Thordarson on 1/5/05.
//  Copyright 2005 Sveinbjorn Thordarson. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface STChecksum : NSObject 
{

}
+ (int) getChecksumForFile: (NSString *)path;
+ (NSString *) getChecksumForFileAsString: (NSString *)path;
+ (BOOL) doesFileMatchChecksum: (NSString *)path checksum: (long) checksum;
+ (BOOL) doesFileMatchChecksumString: (NSString *)path checksumString: (NSString *)checksum;
+ (BOOL) isFileValidForChecksum: (NSString *)path;
@end
