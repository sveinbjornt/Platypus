//
//  SillyStringEncrypt.h
//  Platypus
//
//  Created by Sveinbjorn Thordarson on 1/6/05.
//  Copyright 2005 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface SillyStringEncrypt : NSObject 
{

}
+ (NSString *) rot13: (NSString *)theString;
+ (NSString *) spaceNewlineObfuscate: (NSString *)theString;
+ (NSString *) spaceNewlineDeobfuscate: (NSString *)theString;
+ (NSString *) sillyEncryptString: (NSString *)theStr;
+ (NSString *) sillyDecryptString: (NSString *)theStr;
@end
