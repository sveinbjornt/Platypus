//
//  SillyStringEncrypt.m
//  Platypus
//
//  Created by Sveinbjorn Thordarson on 1/6/05.
//  Copyright 2005 __MyCompanyName__. All rights reserved.
//

#import "SillyStringEncrypt.h"


@implementation SillyStringEncrypt
+ (NSString *) rot13: (NSString *)aString
{
	NSString *newString;
    unsigned length;
    unichar *buf;
    unsigned i;

    length = [aString length];
    buf = malloc( (length + 1) * sizeof(unichar) );
    [aString getCharacters:buf];
    buf[length] = (unichar)0; // not really needed....

    for (i = 0; i < length; i++) 
	{
        if (buf[i] >= (unichar)'a' && buf[i] <= (unichar) 'z')
		{
            buf[i] += 13;
            if (buf[i] > 'z') buf[i] -= 26;
        } 
		else if (buf[i] >= (unichar)'A' && buf[i] <= (unichar) 'Z') 
		{
            buf[i] += 13;
            if (buf[i] > 'Z') buf[i] -= 26;
        }
    }

    newString = [NSString stringWithCharacters:buf length:length];
    free(buf);
    return newString;
}

+ (NSString *) spaceNewlineObfuscate: (NSString *)theString
{
	//replace all newlines with null characters
	theString = [[theString componentsSeparatedByString:@"\n"] componentsJoinedByString:@"\0"];
	//replace all spaces with newlines
	theString = [[theString componentsSeparatedByString:@" "] componentsJoinedByString:@"\n"];
	//replace all null characters with spaces
	theString = [[theString componentsSeparatedByString:@"\0"] componentsJoinedByString:@" "];
	return theString;
}

+ (NSString *) spaceNewlineDeobfuscate: (NSString *)theString
{
	//replace all spaces with null characterrs
	theString = [[theString componentsSeparatedByString:@" "] componentsJoinedByString:@"\0"];
	//replace all newlines with spaces
	theString = [[theString componentsSeparatedByString:@"\n"] componentsJoinedByString:@" "];
	//replace all null characters with newlines
	theString = [[theString componentsSeparatedByString:@"\0"] componentsJoinedByString:@"\n"];
	return theString;
}

+ (NSString *) sillyEncryptString: (NSString *)theStr
{
	theStr = [SillyStringEncrypt rot13: theStr];
	theStr = [SillyStringEncrypt spaceNewlineObfuscate: theStr];
	return theStr;
}

+ (NSString *) sillyDecryptString: (NSString *)theStr
{
	theStr = [SillyStringEncrypt spaceNewlineDeobfuscate: theStr];
	theStr = [SillyStringEncrypt rot13: theStr];
	return theStr;
}

@end
