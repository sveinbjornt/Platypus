/* FileTypesController */

#import <Cocoa/Cocoa.h>
#import "TypesList.h"
#import "SuffixList.h"
#import "STUtil.h"

@interface FileTypesController : NSObject
{
	IBOutlet id appFunctionRadioButtons;
    IBOutlet id addSuffixButton;
    IBOutlet id addTypeButton;
    IBOutlet id numSuffixesTextField;
    IBOutlet id numTypesTextField;
    IBOutlet id removeSuffixButton;
    IBOutlet id removeTypeButton;
    IBOutlet id suffixListDataBrowser;
    IBOutlet id suffixTextField;
    IBOutlet id typeCodeTextField;
    IBOutlet id typesErrorTextField;
    IBOutlet id typesListDataBrowser;
    IBOutlet id typesWindow;
    IBOutlet id window;
	
	SuffixList	*suffixList;
	TypesList	*typesList;
}
- (IBAction)addSuffix:(id)sender;
- (IBAction)addType:(id)sender;
- (IBAction)clearSuffixList:(id)sender;
- (IBAction)clearTypesList:(id)sender;
- (IBAction)openTypesSheet:(id)sender;
- (IBAction)closeTypesSheet:(id)sender;
- (IBAction)removeSuffix:(id)sender;
- (IBAction)removeType:(id)sender;
- (IBAction)setDefaultTypes:(id)sender;

- (TypesList *) types;
- (SuffixList *) suffixes;
@end
