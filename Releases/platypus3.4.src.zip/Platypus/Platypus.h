/*
    Platypus - program for creating Mac OS X application wrappers around scripts
    Copyright (C) 2006 Sveinbjorn Thordarson <sveinbjornt@simnet.is>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/

#import <Cocoa/Cocoa.h>
#import <Carbon/Carbon.h>
#import "FileList.h"
#import "SuffixList.h"
#import "TypesList.h"
#import "IconFamily.h"
#import "STUtil.h"
#import "STChecksum.h"
#import "SillyStringEncrypt.h"
#import "EnvController.h"
#import "IconController.h"
#import "FileTypesController.h"

@interface Platypus : NSObject
{
	//basic controls    
	IBOutlet id appNameTextField;
	IBOutlet id scriptTypeRadioButtons;
    IBOutlet id scriptPathTextField;
	IBOutlet id editScriptButton;
	IBOutlet id revealScriptButton;
	IBOutlet id outputTypeRadioButtons;
	IBOutlet id createAppButton;
    
    IBOutlet id showAdvancedArrow;
	IBOutlet id showOptionsTextField;
	
	//advanced options controls
	IBOutlet id interpreterTextField;
	IBOutlet id versionTextField;
	IBOutlet id signatureTextField;
	IBOutlet id bundleIdentifierTextField;
	IBOutlet id authorTextField;

	IBOutlet id rootPrivilegesCheckbox;
	IBOutlet id encryptCheckbox;
    IBOutlet id isDroppableCheckbox;
	IBOutlet id showInDockCheckbox;
	IBOutlet id remainRunningCheckbox;	
	IBOutlet id editTypesButton;
	
	IBOutlet id appFunctionRadioButtons;
	IBOutlet id toggleAdvancedMenuItem;
	
	//editor
	IBOutlet id editorCheckSyntaxButton;
	IBOutlet id editorWindow;
	IBOutlet id editorScriptPath;
	IBOutlet id editorText;
	
	IBOutlet id commandWindow;
	IBOutlet id commandTextField;
	
	//menus
	IBOutlet id openRecentMenu;
	IBOutlet id profilesMenu;
	
	//suffix list
	IBOutlet id suffixTextField;
	IBOutlet id suffixListDataBrowser;
	IBOutlet id numSuffixesTextField;
	IBOutlet id removeSuffixButton;
	IBOutlet id addSuffixButton;
	
	//types list
	IBOutlet id typeCodeTextField;
	IBOutlet id typesListDataBrowser;
	IBOutlet id numTypesTextField;
	IBOutlet id removeTypeButton;
	IBOutlet id addTypeButton;
	
	IBOutlet id typesErrorTextField;//for reporting when settings are invalid
	
	IBOutlet id syntaxCheckerTextField;
	IBOutlet id syntaxScriptPathTextField;
	
	//windows
	IBOutlet id window;
	IBOutlet id prefsWindow;
	IBOutlet id typesWindow;//sheet
	IBOutlet id syntaxCheckerWindow;//sheet
	IBOutlet id profilesWindow;//sheet
	
	IBOutlet id profilesDataBrowser;
	IBOutlet id removeProfileButton;
	IBOutlet id	loadProfileButton;
	
	//prefs
	IBOutlet id parseShebangCheckbox;
    IBOutlet id revealAppCheckbox;
    IBOutlet id defaultEditorMenu;
	IBOutlet id defaultBundleIdentifierTextField;
	IBOutlet id defaultAuthorTextField;
	
	IBOutlet id envControl;
	IBOutlet id iconControl;
	IBOutlet id typesControl;
	
	FileList			*fileList;
	NSMutableArray		*recentItems;
	NSArray				*defaultInterpreters;
}

- (IBAction)createButtonPressed: (id)sender;
- (void)createApp:(NSSavePanel *)sPanel returnCode:(int)result contextInfo:(void *)contextInfo;
- (IBAction)editScript:(id)sender;
- (IBAction)newScript:(id)sender;
- (IBAction)revealScript:(id)sender;
- (IBAction)runScript:(id)sender;

- (IBAction)scriptTypeSelected:(id)sender;
- (IBAction)selectScript:(id)sender;
- (void)selectScriptPanelDidEnd:(NSOpenPanel *)oPanel returnCode:(int)returnCode contextInfo:(void *)contextInfo;
- (IBAction)toggleAdvancedOptions:(id)sender;

- (IBAction)loadProfile:(id)sender;

- (BOOL)verifyFieldContents;
- (IBAction)isDroppableWasClicked:(id)sender;

- (IBAction)clearAllFields:(id)sender;
- (IBAction)showPrefs:(id)sender;
- (IBAction)applyPrefs:(id)sender;
- (void)setIconsForEditorMenu;

- (NSMutableDictionary *)getInfoPropertyListDictionary: (NSString *)appName isDroppable: (BOOL)droppable inBackground: (BOOL)background;

- (void)setScriptType: (int)typeNum;
- (void)loadScript:(NSString *)filename;
- (int)getFileTypeFromSuffix: (NSString *)fileName;

- (BOOL)performDragOperation:(id <NSDraggingInfo>)sender;
- (NSDragOperation)draggingEntered:(id <NSDraggingInfo>)sender;
- (NSString *)generateBundleIdentifier;
- (BOOL)validateMenuItem:(NSMenuItem*)anItem;
-(void) constructOpenRecentMenu;

//profiles
- (IBAction) saveProfile:(id)sender;
- (void) profileMenuItemSelected: (id)sender;
- (IBAction) clearAllProfiles:(id)sender;
- (void) constructProfilesMenu;
- (IBAction)closeEditProfilesSheet:(id)sender;

//Help
- (IBAction) showHelp:(id)sender;

//Select editor
- (IBAction) selectScriptEditor:(id)sender;
- (void)openScriptInBuiltInEditor: (NSString *)path;
@end
