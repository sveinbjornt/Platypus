//
//  main.m
//  Platypus
//
//  Created by Sveinbjorn Thordarson on Wed Feb 11 2004.
//  Copyright (c) 2004 Sveinbjorn Thordarson <sveinbjornt@simnet.is>. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char *argv[])
{
    return NSApplicationMain(argc, argv);
}
