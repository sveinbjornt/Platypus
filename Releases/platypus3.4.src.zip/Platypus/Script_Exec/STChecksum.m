/*
    ScriptExec - binary bundled into Platypus-created applications
    Copyright (C) 2006 Sveinbjorn Thordarson <sveinbjornt@simnet.is>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#import "STChecksum.h"


@implementation STChecksum

// doesn't work
+ (int) getChecksumForFile: (NSString *)path
{
	NSString *checksumString = [self getChecksumForFileAsString: path];
	if (checksumString == NULL) //not a valid path
		return -1;
	else
		return [checksumString intValue];
}

+ (NSString *) getChecksumForFileAsString: (NSString *)path
{
	if (![self isFileValidForChecksum: path])//make sure file is valid for checksum
		return NULL;

	NSTask			*cksumTask = [[NSTask alloc] init];
	NSPipe			*outputPipe = [NSPipe pipe];
	NSFileHandle	*readHandle;
	NSString		*outputStr;
	
	[cksumTask setLaunchPath: @"/usr/bin/cksum"];
	[cksumTask setArguments: [NSArray arrayWithObjects: path, nil]];
	[cksumTask setStandardOutput: outputPipe];
	readHandle = [outputPipe fileHandleForReading];
	
	[cksumTask launch];
	
	outputStr = [[NSString alloc] initWithData: [readHandle readDataToEndOfFile] encoding: NSASCIIStringEncoding];
	
	NSArray	*components = [outputStr componentsSeparatedByString: @" "];
	NSString *checksumString = [components objectAtIndex: 0];
	
	[cksumTask release];
	[outputStr release];
	return checksumString;
}


// doesn't work
+ (BOOL) doesFileMatchChecksum: (NSString *)path checksum: (long) checksum
{

	return YES;
}

+ (BOOL) doesFileMatchChecksumString: (NSString *)path checksumString: (NSString *)checksum
{
	NSString *fileChecksum = [self getChecksumForFileAsString: path];
	
	return ([fileChecksum isEqualToString: checksum]);
}

+ (BOOL) isFileValidForChecksum: (NSString *)path
{
	BOOL isDir;
	
	if ([[NSFileManager defaultManager] fileExistsAtPath: path isDirectory: &isDir] && !isDir)
		return YES;
	if (isDir)
		NSLog(@"File %@ is a folder", path);
	else
		NSLog(@"File %@ does not exist", path);
	return NO;
}
@end
