#!/bin/sh

/usr/bin/man ./platypus.1 | ./cat2html > platypus.man.html
