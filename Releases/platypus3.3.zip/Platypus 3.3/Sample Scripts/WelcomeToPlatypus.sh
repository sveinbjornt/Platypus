#!/bin/sh
#
# A simple script which bids you hello verbally and opens the Platypus website
#
# Open this script with Platypus and select Output Type: Text Window
#

echo "Hello, $USER.  Welcome to Platypus"
say "Hello, $USER.  Welcome to Platypus"
open http://sveinbjorn.sytes.net/platypus
