#!/usr/bin/perl

foreach (@ARGV)
{
    print $_ . "\n";
}