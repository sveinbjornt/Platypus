#!/bin/sh

echo $@