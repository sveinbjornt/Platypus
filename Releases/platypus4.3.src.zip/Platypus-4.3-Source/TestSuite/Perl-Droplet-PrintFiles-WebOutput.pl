#!/usr/bin/perl

print '<html><body bgcolor="#eee">';

foreach (@ARGV)
{
    print "<center>$_</center>\n";
}