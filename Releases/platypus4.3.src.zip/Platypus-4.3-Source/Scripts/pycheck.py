#!/usr/bin/python

import sys
import compiler
compiler.parseFile(sys.argv[1])
