/*
    ScriptExec - binary bundled into Platypus-created applications
    Copyright (C) 2003-2010 Sveinbjorn Thordarson <sveinbjornt@simnet.is>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#import "ScriptExecController.h"

@implementation ScriptExecController

- (id)init
{
	if ((self = [super init])) 
	{
		// initialise these vars
		task = NULL;
		privilegedTask = NULL;
		statusItem = NULL;
		statusItemTitle = @"";
		statusItemIcon = NULL;
		arguments = [[NSMutableArray alloc] initWithCapacity: ARG_MAX];
		textEncoding = DEFAULT_OUTPUT_TXT_ENCODING;
		isTaskRunning = NO;
		jobQueue = [[NSMutableArray alloc] initWithCapacity: PLATYPUS_MAX_QUEUE_JOBS];
		
		// register for notifications
		[[NSNotificationCenter defaultCenter] addObserver: self
												 selector: @selector(checkTaskStatus:)
													 name: NSTaskDidTerminateNotification
												   object: NULL];
    
		[[NSNotificationCenter defaultCenter] addObserver: self
												 selector: @selector(checkTaskStatus:)
													 name: STPrivilegedTaskDidTerminateNotification
												   object: NULL];
	}
    return self;
}

-(void)dealloc
{
	if (arguments != NULL) { [arguments release]; }
	if (droppableSuffixes != NULL)	{[droppableSuffixes release];}
	if (droppableFileTypes != NULL)	{[droppableFileTypes release];}
	if (jobQueue != NULL) { [jobQueue release]; }
	if (statusItemIcon != NULL) { [statusItemIcon release]; }
	if (script != NULL) { [script release]; }
	[super dealloc];
}

-(void)awakeFromNib
{
	// default to this
	outputTextView = textOutputTextField;
	
	//load settings from app bundle
	[self loadSettings];
	
	//put application name into the relevant menu items
	[quitMenuItem setTitle: [NSString stringWithFormat: @"Quit %@", appName]];
	[aboutMenuItem setTitle: [NSString stringWithFormat: @"About %@", appName]];
	[hideMenuItem setTitle: [NSString stringWithFormat: @"Hide %@", appName]];
	
	// register windows to receive dragged files if app is set to be droppable
	if (isDroppable)
	{
		[progressBarWindow registerForDraggedTypes: [NSArray arrayWithObjects:NSFilenamesPboardType, nil]];
		[textOutputWindow registerForDraggedTypes: [NSArray arrayWithObjects:NSFilenamesPboardType, nil]];
		[webOutputWindow registerForDraggedTypes: [NSArray arrayWithObjects:NSFilenamesPboardType, nil]];
		[webOutputWebView registerForDraggedTypes: [NSArray arrayWithObjects:NSFilenamesPboardType, nil]];
	}
	
	//prepare controls etc. for different output types
	if (outputType == PLATYPUS_PROGRESSBAR_OUTPUT)
	{
		// add menu item for Show Details
		[[windowMenu insertItemWithTitle: @"Toggle Details" action: @selector(performClick:)  keyEquivalent:@"T" atIndex: 2] setTarget: progressBarDetailsTriangle];
		[windowMenu insertItem: [NSMenuItem separatorItem] atIndex: 2];
		
		// style the text field
		outputTextView = progressBarTextField;
		[outputTextView setFont: textFont];
		[outputTextView setTextColor: textForeground];
		[outputTextView setBackgroundColor: textBackground];
		
		if (isDroppable)
			[progressBarMessageTextField setStringValue: @"Drag files to process them"];
		else
			[progressBarMessageTextField setStringValue: @"Running..."];
		
		[progressBarIndicator setUsesThreadedAnimation: YES];
		
		//preare window
		[progressBarWindow setTitle: appName];
		[progressBarWindow center];
		[progressBarWindow makeKeyAndOrderFront: self];
	}
	else if (outputType == PLATYPUS_TEXTWINDOW_OUTPUT)
	{   
		// style the text field
		outputTextView = textOutputTextField;
		[outputTextView setFont: textFont];
		[outputTextView setTextColor: textForeground];
		[outputTextView setBackgroundColor: textBackground];
		[outputTextView setString: @""]; // for some reason this is needed to apply the style -- bug somewhere?
		
		if (isDroppable)
			[textOutputMessageTextField setStringValue: @"Drag files on window to process them"];
		
		[textOutputProgressIndicator setUsesThreadedAnimation: YES];
		
		// prepare window
		[textOutputWindow setTitle: appName];
		[textOutputWindow center];
		[textOutputWindow makeKeyAndOrderFront: self];
	}
	else if (outputType == PLATYPUS_WEB_OUTPUT)
	{
		[webOutputProgressIndicator setUsesThreadedAnimation: YES];
		
		if (isDroppable)
			[webOutputMessageTextField setStringValue: @"Drag files to process"];
		
		// prepare window
		[webOutputWindow setTitle: appName];
		[webOutputWindow center];
		[webOutputWindow makeKeyAndOrderFront: self];		
	}
	else if (outputType == PLATYPUS_STATUSMENU_OUTPUT)
	{
		NSLog(@"Creating status item");
		// create and activate status item
		statusItem = [[[NSStatusBar systemStatusBar] statusItemWithLength: NSVariableStatusItemLength] retain];
		[statusItem setHighlightMode: YES];
		
		if (statusItemTitle != NULL)
		{
			NSLog(@"Title: %@", statusItemTitle);
			[statusItem setTitle: statusItemTitle];
		}
		if (statusItemIcon != NULL)
		{
			NSLog(@"Loading status item icon");
			[statusItem setImage: statusItemIcon];
		}
		[statusItem setMenu: statusItemMenu];
		[statusItem setEnabled: YES];
		
		//create Quit menu
		NSMenuItem *menuItem = [[[NSMenuItem alloc] initWithTitle: [NSString stringWithFormat: @"Quit %@", appName] action: @selector(terminate:) keyEquivalent: @""] autorelease];
		[statusItemMenu insertItem: menuItem atIndex: 0];
		[statusItemMenu insertItem: [NSMenuItem separatorItem] atIndex: 0];
	}
	
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{	
	// droppable apps don't run on launch -- only when they're handed files
	// likewise, status menu apps just run when item is clicked
	// for all others, we run the script once app is up and running
	if ((!isDroppable || [jobQueue count] > 0) && outputType != PLATYPUS_STATUSMENU_OUTPUT)
		[self executeScript];
}

#pragma mark -

//
// set up controls, construct arguments list etc.
// before actually running the script
//
- (void)prepareForExecution
{
	//if it is a "secure" script, we decode and write it to /tmp/
	if (secureScript)
	{
		// make sure we can write to the temp directory
		if (![[NSFileManager defaultManager] isWritableFileAtPath: TMP_PATH])
			[STUtil fatalAlert: @"Unable to write temporary files" subText: [NSString stringWithFormat: @"Could not write to the %@ directory.  Make sure this directory exists and that you have write privileges.", TMP_PATH]]; 		
		
		NSString *tempScript;
		// create a new file with random name in PLATYPUS_TEMP_SCRIPT_PATH
		// get a random number to append to script name in /tmp/
		do
		{
			int randnum =  random() / 1000000;
			tempScript = [NSString stringWithFormat: @"%@.%d", [PLATYPUS_TEMP_SCRIPT_PATH stringByExpandingTildeInPath], randnum];
		}
		while ([[NSFileManager defaultManager] fileExistsAtPath: tempScript]);
				
		// write script
		[script writeToFile: tempScript atomically: YES];
		scriptPath = [NSString stringWithString: tempScript];
	}
	
	// set all the progress indicators off, update controls, messages etc.
	if (outputType == PLATYPUS_PROGRESSBAR_OUTPUT)
	{
		//prepare progress bar
		[progressBarIndicator setIndeterminate: YES];
		[progressBarIndicator startAnimation: self];
		[progressBarMessageTextField setStringValue: @"Running..."];
		[outputTextView setString: @"\n"];
		[progressBarCancelButton setTitle: @"Cancel"];
		if (execStyle == PLATYPUS_PRIVILEGED_EXECUTION) { [progressBarCancelButton setEnabled: NO]; }
	}
	else if (outputType == PLATYPUS_TEXTWINDOW_OUTPUT)
	{   
		[textOutputTextField setString: @"\n"];
		[textOutputCancelButton setTitle: @"Cancel"];
		if (execStyle == PLATYPUS_PRIVILEGED_EXECUTION) { [textOutputCancelButton setEnabled: NO]; }
		[textOutputProgressIndicator startAnimation: self];
	}
	else if (outputType == PLATYPUS_WEB_OUTPUT)
	{
		[outputTextView setString: @"\n"];
		[webOutputCancelButton setTitle: @"Cancel"];
		if (execStyle == PLATYPUS_PRIVILEGED_EXECUTION) { [webOutputCancelButton setEnabled: NO]; }
		[webOutputProgressIndicator startAnimation: self];
	}
	else if (outputType == PLATYPUS_STATUSMENU_OUTPUT)
		[outputTextView setString: @""];
	
	//clear arguments list and reconstruct it
	// clean these so they're ready for script execution
	[arguments removeAllObjects];
	
	// first, add all specified arguments for interpreter
	if ([paramsArray count] > 0)
		[arguments addObjectsFromArray: paramsArray];

	// add script as argument to interpreter
	if (![[NSFileManager defaultManager] fileExistsAtPath: scriptPath])
		[STUtil fatalAlert: @"Missing script" subText: @"Script missing at execution path"];
	[arguments addObject: scriptPath];
	
	//set $1 as path of application bundle if that option is set
	if (appPathAsFirstArg)
		[arguments addObject: [[NSBundle mainBundle] bundlePath]]; 
	
	//finally, add any file arguments we may have received as dropped/opened
	if ([jobQueue count] > 0) // we have files in the queue, to append as arguments
	{
		[arguments addObjectsFromArray: [jobQueue objectAtIndex: 0]];
		[[jobQueue objectAtIndex: 0] release]; // release
		[jobQueue removeObjectAtIndex: 0]; // remove it from the queue
	}
}

- (void)executeScript
{
	isTaskRunning = YES;
	[self prepareForExecution];
	
	if (execStyle == PLATYPUS_PRIVILEGED_EXECUTION) //authenticated task
		[self executeScriptWithPrivileges];
	else //plain old regular nstask
		[self executeScriptWithoutPrivileges];
}

#pragma mark -

//launch regular user task with NSTask
- (void)executeScriptWithoutPrivileges
{	
	//initalize task
	task = [[NSTask alloc] init];
	
	//apply settings for task
	[task setLaunchPath: interpreter];
	[task setCurrentDirectoryPath: [[NSBundle mainBundle] resourcePath]];
	[task setArguments: arguments];
	
	// set output to file handle and start monitoring it
	outputPipe = [NSPipe pipe];
	[task setStandardOutput: outputPipe];
	[task setStandardError: outputPipe];
	readHandle = [outputPipe fileHandleForReading];
	
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getTextData:) name: NSFileHandleReadCompletionNotification object:readHandle];
	[readHandle readInBackgroundAndNotify];
	
	//[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getTextData:) name: NSFileHandleReadToEndOfFileCompletionNotification object:readHandle];
	//[readHandle readToEndOfFileInBackgroundAndNotify];
	
	//set it off
	[task launch];

	// we wait until task exits if this is for the menu
	if (outputType == PLATYPUS_STATUSMENU_OUTPUT)
	{
		[task waitUntilExit];
	}
}

//launch task with admin privileges using Authentication Manager
- (void)executeScriptWithPrivileges
{	
	//initalize task
	privilegedTask = [[STPrivilegedTask alloc] init];
	
	//apply settings for task
	[privilegedTask setLaunchPath: interpreter];
	[privilegedTask setCurrentDirectoryPath: [[NSBundle mainBundle] resourcePath]];
	[privilegedTask setArguments: arguments];
	
	//set it off
	OSStatus err = [privilegedTask launch];
	if (err != errAuthorizationSuccess)
	{
		if (err == errAuthorizationCanceled)
			[self taskFinished];
		else // something went wrong
			[STUtil fatalAlert: @"Failed to execute script" subText: @"An error occurred while executing script with privileges.  This application will now terminate."];
	}
	else
	{
		// Success!  Now, start monitoring output file handle for data
		readHandle = [privilegedTask outputFileHandle];
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getTextData:) name:NSFileHandleReadCompletionNotification object:readHandle];
		[readHandle readInBackgroundAndNotify];
	}
}

// handle notification that task is done
- (void)checkTaskStatus:(NSNotification *)aNotification
{
	[self taskFinished];
}

#pragma mark -

// OK, called when task is finished.  Some cleaning up to do, controls need to be adjusted, etc.
- (void)taskFinished
{	
		// make sure task is dead.  Ideally we'd like to do the same for privileged tasks, but that's just not possible w/o process id
		if (task != NULL && [task isRunning] && execStyle == PLATYPUS_NORMAL_EXECUTION)
			[task terminate];
			
		//if we're using the "encrypted" script, we must remove the temporary clear-text one in /tmp/ if there is one
		if (secureScript && [[NSFileManager defaultManager] fileExistsAtPath: scriptPath])
			[[NSFileManager defaultManager] removeFileAtPath: scriptPath handler: nil];

		if (!remainRunning)
		{	
			// we quit if the app isn't set to continue running
			[[NSApplication sharedApplication] terminate: self];
		}
		else if (outputType == PLATYPUS_TEXTWINDOW_OUTPUT)
		{
			//update controls for text output window
			[textOutputCancelButton setTitle: @"Quit"];
			[textOutputCancelButton setEnabled: YES];
			[textOutputProgressIndicator stopAnimation: self];
		}
		else if (outputType == PLATYPUS_PROGRESSBAR_OUTPUT)
		{
			//update controls for progress bar output
			[progressBarIndicator stopAnimation: self];
			
			if (isDroppable)
			{
				[progressBarMessageTextField setStringValue: @"Drag files to process"];
				[progressBarIndicator setIndeterminate: YES];
			}
			else 
			{
				// set last line of output as status message
				int		 llindex = [self indexOfLastLine: [outputTextView string]];
				NSString *lastLineOfOutput = [[outputTextView string] substringWithRange: NSMakeRange(llindex, [[outputTextView string] length]-llindex)];
				[progressBarMessageTextField setStringValue: lastLineOfOutput];
				
				// cleanup - if the script didn't give us a proper status message, then we set one
				if ([[progressBarMessageTextField stringValue] isEqualToString: @""] || 
					[[progressBarMessageTextField stringValue] isEqualToString: @"\n"] || 
					[[progressBarMessageTextField stringValue] isEqualToString: @"Running..."])
					[progressBarMessageTextField setStringValue: @"Task completed"];
				
				[progressBarIndicator setIndeterminate: NO];
				[progressBarIndicator setDoubleValue: 100];
			}
			// change button
			[progressBarCancelButton setTitle: @"Quit"];
			[progressBarCancelButton setEnabled: YES];
		}
		else if (outputType == PLATYPUS_WEB_OUTPUT)
		{
			//update controls for web output window
			[webOutputCancelButton setTitle: @"Quit"];
			[webOutputCancelButton setEnabled: YES];
			[webOutputProgressIndicator stopAnimation: self];
		}
	
		isTaskRunning = NO;
	
		// if there are more jobs waiting for us, execute
		if ([jobQueue count] > 0)
			[self executeScript];
}

//  read from the file handle and append it to the text window
- (void) getTextData: (NSNotification *)aNotification
{
	//get the data from notification
	NSData *data = [[aNotification userInfo] objectForKey: NSFileHandleNotificationDataItem];
	
	//make sure there's actual data
	if ([data length]) 
	{
		//append the output to the text field		
		[self appendOutput: data];
		
		// we schedule the file handle to go and read more data in the background again.
		[[aNotification object] readInBackgroundAndNotify];
	}
}

//
// this function receives all new data dumped out by the script and appends it to text field
// it is *relatively* memory efficient (given the nature of NSTextView) and doesn't leak, as far as I can tell...
//
- (void)appendOutput:(NSData *)data
{
	// we decode the script output according to specified character encoding
	NSString *outputString = [[[NSString alloc] initWithData: data encoding: textEncoding] autorelease];
	
	// if it's just empty junk
	if (!outputString)
		return;

	// this is WAY faster and more efficient than stringByAppendingString
	NSTextStorage *text = [outputTextView textStorage];
	[text replaceCharactersInRange:NSMakeRange([text length], 0) withString: outputString];
	
	// if web output, we continually re-render to accomodate incoming data, else we scroll down
	if (outputType == PLATYPUS_WEB_OUTPUT)
		[[webOutputWebView mainFrame] loadHTMLString: [outputTextView string] baseURL: [NSURL fileURLWithPath: [[NSBundle mainBundle] resourcePath]] ];
	else if (outputType == PLATYPUS_TEXTWINDOW_OUTPUT)
		[outputTextView scrollRangeToVisible: NSMakeRange([text length], 0)];
	else if (outputType == PLATYPUS_PROGRESSBAR_OUTPUT)
	{			
		[outputTextView scrollRangeToVisible:NSMakeRange([text length], 0)];

		// progress bar is a bit different - we need to parse for complete lines of text to put in status text field
		// this is a bit slow, unfortunately
		NSString *wholeLine = [self getLastWholeNewlineOfOutput: [outputTextView string]];
		if ([wholeLine caseInsensitiveCompare: @""] != NSOrderedSame) // if the line is empty, we ignore it
		{
			if ([wholeLine hasPrefix: @"PROGRESS:"])
			{					
				NSString *progressPercent = [wholeLine substringFromIndex: 9];
				[progressBarIndicator setIndeterminate: NO];
				[progressBarIndicator setDoubleValue: [progressPercent doubleValue]];
			}
			else if (![wholeLine isEqualToString: @""])
				[progressBarMessageTextField setStringValue: wholeLine];
		}
	}
}


#pragma mark -

// String parsing stuff

// this function looks at a given string and extracts the latest
// whole newline, i.e. the last complete line of text
//
// we need this for dumping line output into the progress bar status text field
//
- (NSString *)getLastWholeNewlineOfOutput: (NSString *)str
{
	int		i;
	int		llstart = [self indexOfLastLine: str];
	
	// get the line before the last line
	for (i = llstart-1; i >= 0; i--)
	{
		if (i == 0 || [str characterAtIndex: i-1] == '\n')
		{
			NSRange llRange = NSMakeRange(i, llstart-i-1);
			return [str substringWithRange: llRange];
		}
	}
	return @"";
}
-(int)indexOfLastLine: (NSString *)str
{	
	int i;
	for (i = [str length]-1; i >= 0; i--)
	{
		if (i == 0 || [str characterAtIndex: i-1] == '\n')
			return i;
	}
	return 0;
}

#pragma mark -

- (void)application:(NSApplication *)theApplication openFiles:(NSArray *)filenames
{
	if (isDroppable)
	{
		NSMutableArray *args = [[NSMutableArray alloc] initWithCapacity: ARG_MAX]; //this object is released in prepareForExecution
		[args addObjectsFromArray: filenames];
		[jobQueue addObject: args];
		
		if (!isTaskRunning && isDroppable)
			[self executeScript];
	}
	
	if (statusItem != NULL)
		[[NSStatusBar systemStatusBar] removeStatusItem: statusItem];
}

- (NSApplicationTerminateReply)applicationShouldTerminate:(NSApplication *)sender
{	
	//terminate task
	if (task != NULL)
	{
		if ([task isRunning])
			[task terminate];
		[task release];
	}
	
	if (privilegedTask != NULL)
		[privilegedTask release];
	
	[jobQueue removeAllObjects];
	
	// just one more time, make sure we don't leave the clear-text script in the /tmp/ directory
	if ([[NSFileManager defaultManager] fileExistsAtPath: PLATYPUS_TEMP_SCRIPT_PATH])
		[[NSFileManager defaultManager] removeFileAtPath: PLATYPUS_TEMP_SCRIPT_PATH handler: nil];
	
	return(YES);
}

#pragma mark -

// returns whether a given file is accepted by the suffix/types criterion specified in AppSettings.plist
- (BOOL)acceptableFileType: (NSString *)file
{
	int i;
	BOOL isDir;
	
	// Check if it's a folder. If so, we only accept it if 'fold' is specified as accepted file type
	if ([[NSFileManager defaultManager] fileExistsAtPath: file isDirectory: &isDir] && isDir)
	{
		for(i = 0; i < [droppableFileTypes count]; i++)
		{
			
			if([[droppableFileTypes objectAtIndex: i] isEqualToString: @"fold"])
				return YES;
		}
		return NO;
	}
	
	if (acceptANYDroppedItem)
		return YES;
	
	// see if it has accepted suffix
	for (i = 0; i < [droppableSuffixes count]; i++)
	{
		if ([file hasSuffix: [droppableSuffixes objectAtIndex: i]])
			return YES;
	}
	
	// see if it has accepted file type
	NSString *fileType = NSHFSTypeOfFile(file);
	for(i = 0; i < [droppableFileTypes count]; i++)
	{
		if([fileType isEqualToString: [droppableFileTypes objectAtIndex: i]])
			return YES;
	}
	
	return NO;
}

- (NSDragOperation)draggingEntered:(id <NSDraggingInfo>)sender 
{ 
	// check file types against acceptable drop types here before accepting them
	int i;
    NSPasteboard *pboard = [sender draggingPasteboard];
	NSArray *files = [pboard propertyListForType:NSFilenamesPboardType];

	if (!isDroppable || ![[pboard types] containsObject:NSFilenamesPboardType])
		return NSDragOperationNone;
	
	// see if any of the dragged files are acceptable
	for (i = 0; i < [files count]; i++)
	{
		if ([self acceptableFileType: [files objectAtIndex: i]])
			return NSDragOperationLink;
	}
	
    return NSDragOperationNone;
}

- (BOOL)performDragOperation:(id <NSDraggingInfo>)sender
{ 
	// check file types against acceptable drop types here before accepting them
	int i;
    NSPasteboard *pboard = [sender draggingPasteboard];
	NSArray *files = [pboard propertyListForType:NSFilenamesPboardType];
	NSMutableArray *acceptedFiles = [[[NSMutableArray alloc] init] autorelease];
	
	// Only accept the drag if at least one of the files meets the required types
	for (i = 0; i < [files count]; i++)
	{			
		// if we accept this item, add it to list of accepted files
		if ([self acceptableFileType: [files objectAtIndex: i]])
			[acceptedFiles addObject: [files objectAtIndex: i]];
	}
	
	// if there are any accepted files, we create a processing job and add the files as arguments, accept drop
	if ([acceptedFiles count] > 0)
	{
		NSMutableArray *args = [[NSMutableArray alloc] initWithCapacity: ARG_MAX];//this object is released in prepareForExecution
		[args addObjectsFromArray: acceptedFiles];
		[jobQueue addObject: args];
		return YES;
	}

	return NO;
}

// once the drag is over, we immediately execute w. files as arguments if not already processing
- (void)concludeDragOperation:(id <NSDraggingInfo>)sender
{
	if (isDroppable && !isTaskRunning && [jobQueue count] > 0)
		[self executeScript];
}

- (NSDragOperation)draggingUpdated:(id <NSDraggingInfo>)sender
{
	return [self draggingEntered: sender];
}

- (BOOL)prepareForDragOperation:(id <NSDraggingInfo>)sender
{
	return YES;
}

#pragma mark -

// scroll to the bottom of the view every time frame has rendered
- (void)webView:(WebView *)sender didFinishLoadForFrame:(WebFrame *)frame
{
	NSScrollView *scrollView = [[[[webOutputWebView mainFrame] frameView] documentView] enclosingScrollView];	
	NSRect bounds = [[[[webOutputWebView mainFrame] frameView] documentView] bounds];
	[[scrollView documentView] scrollPoint: NSMakePoint(0, bounds.size.height)];
}

#pragma mark -

- (void)menuNeedsUpdate:(NSMenu *)menu
{	
	int i;
	
	[self executeScript];
	while (isTaskRunning) {}
	
	NSMutableArray *lines = (NSMutableArray *)[[textOutputTextField string] componentsSeparatedByString: @"\n"];
	
	// clean out any trailing newlines
	while ([[lines lastObject] isEqualToString: @""])
		[lines removeLastObject];
	
	NSDictionary *textAttributes = [NSDictionary dictionaryWithObjectsAndKeys:
									textForeground, NSForegroundColorAttributeName, 
									textFont, NSFontAttributeName,
									NULL];
	
	// remove all items of previous output
	while ([statusItemMenu numberOfItems] > 2)
		[statusItemMenu removeItemAtIndex: 0];
	
	//populate menu with output from task
	for (i = [lines count]-1; i >= 0; i--)
	{		
		// create the menu item
		NSMenuItem *menuItem = [[[NSMenuItem alloc] initWithTitle: @"" action: NULL keyEquivalent: @""] autorelease];
		
		// set the menu item string
		NSAttributedString *attStr = [[[NSAttributedString alloc] initWithString: [lines objectAtIndex: i] attributes: textAttributes] autorelease];
		[menuItem setAttributedTitle: attStr];
		[menu insertItem: menuItem atIndex: 0];
	}
}


#pragma mark -

//load configuration files from application bundle
- (void)loadSettings
{
	int				i = 0;
	NSBundle		*appBundle = [NSBundle mainBundle];
	NSFileManager   *fmgr = [NSFileManager defaultManager];
	NSDictionary	*appSettingsPlist;
	
	//make sure all the config files are present -- if not, we quit
	if (![fmgr fileExistsAtPath: [appBundle pathForResource:@"AppSettings.plist" ofType:nil]])
		[STUtil fatalAlert: @"Corrupt app bundle" subText: @"Vital configuration file missing from the application bundle."];
	
	//get app name
	appName = [[[appBundle executablePath] lastPathComponent] retain];
	
	//get dictionary with app settings
	appSettingsPlist = [NSDictionary dictionaryWithContentsOfFile: [appBundle pathForResource:@"AppSettings.plist" ofType:nil]];
	if (appSettingsPlist == NULL)
		[STUtil fatalAlert: @"Corrupt app settings" subText: @"The AppSettings.plist file for this application is corrupt or missing."]; 
	
	//determine output type
	NSString *outputTypeStr = [appSettingsPlist objectForKey:@"OutputType"];
	if ([outputTypeStr isEqualToString: @"Progress Bar"])
		outputType = PLATYPUS_PROGRESSBAR_OUTPUT;
	else if ([outputTypeStr isEqualToString: @"Text Window"])
		outputType = PLATYPUS_TEXTWINDOW_OUTPUT;
	else if ([outputTypeStr isEqualToString: @"Web View"])
		outputType = PLATYPUS_WEB_OUTPUT;
	else if ([outputTypeStr isEqualToString: @"Status Menu"])
		outputType = PLATYPUS_STATUSMENU_OUTPUT;
	else if ([outputTypeStr isEqualToString: @"None"])
		outputType = PLATYPUS_NO_OUTPUT;
	else
		[STUtil fatalAlert: @"Corrupt app settings" subText: @"Invalid Output Mode settings."];

	
	// we need some additional info from AppSettings.plist if we are presenting textual output
	if (outputType == PLATYPUS_PROGRESSBAR_OUTPUT || 
		outputType == PLATYPUS_TEXTWINDOW_OUTPUT ||
		outputType == PLATYPUS_STATUSMENU_OUTPUT )
	{
		//make sure all this data is sane 
		
		// font and size
		if ([appSettingsPlist objectForKey:@"TextFont"] != NULL || [appSettingsPlist objectForKey:@"TextSize"] != NULL)
			textFont = [NSFont fontWithName: DEFAULT_OUTPUT_FONT size: DEFAULT_OUTPUT_FONTSIZE];
		if (textFont == NULL);
			textFont = [NSFont fontWithName: [appSettingsPlist objectForKey:@"TextFont"] size: [[appSettingsPlist objectForKey:@"TextSize"] floatValue]];
			
		// foreground
		if ([appSettingsPlist objectForKey:@"TextForeground"] == NULL)
			textForeground = [STUtil colorFromHex: DEFAULT_OUTPUT_FG_COLOR];
		if (textForeground == NULL)
			textForeground	= [STUtil colorFromHex: [appSettingsPlist objectForKey:@"TextForeground"]];
		
		// background
		if ([appSettingsPlist objectForKey:@"TextBackground"] == NULL)
			textBackground = [STUtil colorFromHex: DEFAULT_OUTPUT_BG_COLOR];
		if (textBackground == NULL)
			textBackground	= [STUtil colorFromHex:  [appSettingsPlist objectForKey:@"TextBackground"]];
		
		// encoding
		if (textEncoding < 1)
			textEncoding = DEFAULT_OUTPUT_TXT_ENCODING;
		else
			textEncoding	= (int)[[appSettingsPlist objectForKey:@"TextEncoding"] intValue];
		
		[textFont retain];
		[textForeground retain];
	}
	
	// likewise, status menu output has some additional parameters
	if (outputType == PLATYPUS_STATUSMENU_OUTPUT)
	{
		// we load text label if status menu isn't only icon
		if (![[appSettingsPlist objectForKey: @"StatusItemDisplayType"] isEqualToString: @"Icon"])
		{
			statusItemTitle = [[appSettingsPlist objectForKey: @"StatusItemTitle"] retain];
		}
		
		// we load icon if status menu isn't only text label
		if (![[appSettingsPlist objectForKey: @"StatusItemDisplayType"] isEqualToString: @"Text"])
		{
			statusItemIcon = [[NSImage alloc] initWithData: [appSettingsPlist objectForKey: @"StatusItemIcon"]];
			if (statusItemIcon == NULL)
				NSLog(@"Status Icon is NULL");
		}
	}
	
	//arguments to interpreter
	paramsArray = [[NSArray arrayWithArray: [appSettingsPlist objectForKey:@"InterpreterParams"]] retain];
	
	//pass app path as first arg?
	appPathAsFirstArg = [[appSettingsPlist objectForKey:@"AppPathAsFirstArg"] boolValue];
	
	//determine execution style
	execStyle = [[appSettingsPlist objectForKey:@"RequiresAdminPrivileges"] boolValue];
	
	//remain running?
	remainRunning = [[appSettingsPlist objectForKey:@"RemainRunningAfterCompletion"] boolValue];
	
	//is script encrypted and checksummed?
	secureScript = [[appSettingsPlist objectForKey: @"Secure"] boolValue];
	
	//can the app receive dropped files as args?
	isDroppable = [[appSettingsPlist objectForKey: @"Droppable"] boolValue];
	
	// never priv execution or droppable w. status menu
	if (outputType == PLATYPUS_STATUSMENU_OUTPUT) 
	{
		remainRunning = YES;
		execStyle = PLATYPUS_NORMAL_EXECUTION;
		isDroppable = NO;
	}
	
	//if app is droppable, the AppSettings.plist contains list of accepted file types / suffixes
	acceptANYDroppedItem = NO; // initialize this to NO, then check the droppableSuffixes for *, and droppableFiles for ****
	if (isDroppable)
	{	
		// get list of accepted suffixes
		if([appSettingsPlist objectForKey: @"DropSuffixes"])
			droppableSuffixes = [[NSArray alloc] initWithArray:  [appSettingsPlist objectForKey:@"DropSuffixes"]];
		else
			droppableSuffixes = [[NSArray alloc] initWithArray: [NSArray array]];
		[droppableSuffixes retain];
		
		// get list of accepted file types
		if([appSettingsPlist objectForKey:@"DropTypes"])
			droppableFileTypes = [[NSArray alloc] initWithArray:  [appSettingsPlist objectForKey:@"DropTypes"]];
		else
			droppableFileTypes = [[NSArray alloc] initWithArray: [NSArray array]];
		[droppableFileTypes retain];
		
		// see if we accept any dropped item
		for (i = 0; i < [droppableSuffixes count]; i++)
		{
			if ([[droppableSuffixes objectAtIndex:i] isEqualToString:@"*"])
				acceptANYDroppedItem = YES;
		}

		for (i = 0; i < [droppableFileTypes count]; i++)
		{
			if([[droppableFileTypes objectAtIndex:i] isEqualToString:@"****"])
				acceptANYDroppedItem = YES;
		}
	}
	
	//get interpreter
	interpreter = [[NSString stringWithString: [appSettingsPlist objectForKey:@"ScriptInterpreter"]] retain];
	
	//if the script is not "secure" then we need a script file, otherwise we need data in AppSettings.plist
	if ((!secureScript && ![fmgr fileExistsAtPath: [appBundle pathForResource:@"script" ofType: NULL]]) || (secureScript && [appSettingsPlist objectForKey:@"TextSettings"] == NULL))
		[STUtil fatalAlert: @"Corrupt app bundle" subText: @"Script missing from application bundle."];
	
	//get path to script
	if (!secureScript)
		scriptPath = [[NSString stringWithString: [appBundle pathForResource:@"script" ofType:nil]] retain];	
	else //if we have a "secure" script, no path to get
	{
		NSData *b_str = [NSKeyedUnarchiver unarchiveObjectWithData: [appSettingsPlist objectForKey:@"TextSettings"]];
		if (b_str == NULL)
			[STUtil fatalAlert: @"Corrupt app bundle" subText: @"Script missing from application bundle."];
	
		//NSData *sd = [NSData dataWithBytes: b_str length: [b_str length]];
		script = [[NSString alloc] initWithData: b_str encoding: textEncoding];
	}
}

// Respond to Cancel by stopping task (if drop) or else quitting application
- (IBAction)cancel:(id)sender
{
	if ([[sender title] isEqualToString: @"Quit"])
		[[NSApplication sharedApplication] terminate: self];
	else
		[self taskFinished];
}

// show / hide the details text field in progress bar output
- (IBAction)toggleDetails: (id)sender
{
	NSRect winRect = [progressBarWindow frame];
	
	if ([sender state] == NSOffState)
	{
		[progressBarWindow setShowsResizeIndicator: NO];
		winRect.origin.y += 224;
		winRect.size.height -= 224;		
		[progressBarWindow setFrame: winRect display: TRUE animate: TRUE];
	}
	else if ([sender state] == NSOnState)
	{
		[progressBarWindow setShowsResizeIndicator: YES];
		winRect.origin.y -= 224;
		winRect.size.height += 224;
		[progressBarWindow setFrame: winRect display: TRUE animate: TRUE];
	}
}

@end
