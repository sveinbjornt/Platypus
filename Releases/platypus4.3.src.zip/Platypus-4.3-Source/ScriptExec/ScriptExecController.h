/*
    ScriptExec - binary bundled into Platypus-created applications
    Copyright (C) 2003-2010 Sveinbjorn Thordarson <sveinbjornt@simnet.is>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#import <Cocoa/Cocoa.h>
#import <Security/Authorization.h>
#import <WebKit/WebKit.h>
#import <sys/syslimits.h>

#import "STUtil.h"
#import "CommonDefs.h"
#import "STPrivilegedTask.h"
#import "STDragWebView.h"

// output modes
#define	PLATYPUS_NO_OUTPUT					1
#define	PLATYPUS_PROGRESSBAR_OUTPUT			2
#define	PLATYPUS_TEXTWINDOW_OUTPUT			3
#define PLATYPUS_WEB_OUTPUT					4
#define PLATYPUS_STATUSMENU_OUTPUT			5

// execution style
#define PLATYPUS_NORMAL_EXECUTION			0
#define PLATYPUS_PRIVILEGED_EXECUTION		1

// path to temp script file
#define	PLATYPUS_TEMP_SCRIPT_PATH			@"/tmp/.plx_tmp"

#define PLATYPUS_MAX_QUEUE_JOBS				256

@interface ScriptExecController : NSObject
{
    IBOutlet id progressBarCancelButton;
    IBOutlet id progressBarMessageTextField;
    IBOutlet id progressBarIndicator;
	IBOutlet id progressBarWindow;
	IBOutlet id progressBarTextField;
	IBOutlet id progressBarDetailsTriangle;
	IBOutlet id progressBarDetailsLabel;
	
	IBOutlet id textOutputWindow;
	IBOutlet id textOutputCancelButton;
	IBOutlet id textOutputTextField;
	IBOutlet id textOutputProgressIndicator;
	IBOutlet id textOutputMessageTextField;
	
	IBOutlet id webOutputWindow;
	IBOutlet id webOutputCancelButton;
	IBOutlet id webOutputWebView;
	IBOutlet id webOutputProgressIndicator;
	IBOutlet id webOutputMessageTextField;
	
	// status item stuff
	NSStatusItem	*statusItem;
	IBOutlet id		statusItemMenu;
	
	//menu items
	IBOutlet id hideMenuItem;
	IBOutlet id quitMenuItem;
	IBOutlet id aboutMenuItem;
	
	NSTextView	*outputTextView;
		
	IBOutlet id windowMenu;
	
	NSTask				*task;
	STPrivilegedTask	*privilegedTask;
	
	NSTimer			*checkStatusTimer;

	NSPipe			*outputPipe;
	NSFileHandle	*readHandle;

	NSMutableArray  *arguments;
	NSMutableArray  *fileArgs;
	NSArray			*paramsArray;

	NSString		*interpreter;
	NSString		*scriptPath;
	NSString		*appName;
	
	NSFont			*textFont;
	NSColor			*textForeground;
	NSColor			*textBackground;
	int				 textEncoding;
	
	int			appPathAsFirstArg;
	int			execStyle;
	int			outputType;
	int			isDroppable;
	int			remainRunning;
	int			secureScript;
	
	NSArray		*droppableSuffixes;
	NSArray		*droppableFileTypes;
	BOOL		acceptANYDroppedItem;
	
	NSString	*statusItemTitle;
	NSImage		*statusItemIcon;

	BOOL		isTaskRunning;
	
	int			childPid;	
	NSString	*script;
	
	NSMutableArray *jobQueue;
}
- (void)prepareForExecution;
- (void)executeScript;
- (void)executeScriptWithoutPrivileges;
- (void)executeScriptWithPrivileges;
- (void)checkTaskStatus:(NSNotification *)aNotification;
- (void)taskFinished;
- (void)getTextData: (NSNotification *)aNotification;
- (void)appendOutput:(NSData *)data;
- (NSString *)getLastWholeNewlineOfOutput: (NSString *)str;
-(int)indexOfLastLine: (NSString *)str;
- (BOOL)acceptableFileType: (NSString *)file;
- (void)loadSettings;
- (IBAction)cancel:(id)sender;
- (IBAction)toggleDetails: (id)sender;
@end
