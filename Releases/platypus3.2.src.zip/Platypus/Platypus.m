/*
    Platypus - program for creating Mac OS X application wrappers around scripts
    Copyright (C) 2005 Sveinbjorn Thordarson <sveinbt@hi.is>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/

#include <unistd.h>
#import "Platypus.h"


#define	PROGRAM_STAMP	"Platypus-3.2"

@implementation Platypus

/*****************************************
 - init function
*****************************************/
- (id)init
{
	if (self = [super init]) 
	{
		//create file list
		typesList = [[TypesList alloc] init];
		suffixList = [[SuffixList alloc] init];
		recentItems = [[NSMutableArray alloc] initWithCapacity: 10];
    }
    return self;
}

/*****************************************
 - dealloc for controller object
   release all the stuff we alloc in init
*****************************************/
-(void)dealloc
{
	[typesList release];
	[suffixList release];
	[recentItems release];
    [super dealloc];
}

/*****************************************
 - When application is launched by the user for the very first time
*****************************************/
+ (void)initialize 
{ 
	// create the user defaults here if none exists
    // create a dictionary
    NSMutableDictionary *defaultPrefs = [NSMutableDictionary dictionary];
    // put default prefs in the dictionary
	[defaultPrefs setObject: [NSNumber numberWithBool:YES] forKey:@"ParseShebangLineForInterpreter"];
	[defaultPrefs setObject: [NSNumber numberWithBool:NO]  forKey:@"RevealApplicationWhenCreated"];
	[defaultPrefs setObject: NSFullUserName() forKey: @"DefaultAuthor"];
	NSString *bundleId = [NSString stringWithFormat: @"org.%@.", NSUserName()];
	bundleId = [[bundleId componentsSeparatedByString:@" "] componentsJoinedByString:@""];//no spaces
	[defaultPrefs setObject: bundleId forKey: @"DefaultBundleIdentifierPrefix"];
	[defaultPrefs setObject: @"Built-In"  forKey:@"DefaultEditor"];
	[defaultPrefs setObject: [NSNumber numberWithBool:NO] forKey:@"ShowAdvancedOptions"];
	[defaultPrefs setObject: [NSArray array] forKey:@"Profiles"];
	
    // register the dictionary of defaults
    [[NSUserDefaults standardUserDefaults] registerDefaults: defaultPrefs];
}

/*****************************************
 - Handler for when app is done launching
 - Set up the window and stuff like that
*****************************************/
- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
	[self clearAllFields: self];

	//set up window
	[window center];
	if ([[NSUserDefaults standardUserDefaults] boolForKey:@"ShowAdvancedOptions"] == YES)
	{
		[showAdvancedArrow setState: YES];
		[self toggleAdvancedOptions: self];
	}
	[window registerForDraggedTypes: [NSArray arrayWithObjects:NSFilenamesPboardType, nil]];
	[window makeKeyAndOrderFront: NULL];//show window

	//load recent items
	[recentItems addObjectsFromArray: [[NSUserDefaults standardUserDefaults] objectForKey:@"RecentItems"]];
	[self constructOpenRecentMenu];
	
	//load profiles
	[self constructProfilesMenu];
}

/*****************************************
 - Handler for application termination
*****************************************/
- (void)applicationWillTerminate:(NSNotification *)aNotification
{
	//save recent items
	[[NSUserDefaults standardUserDefaults] setObject: recentItems  forKey:@"RecentItems"];
	
	//save window status
	[[NSUserDefaults standardUserDefaults] setBool: [showAdvancedArrow state]  forKey:@"ShowAdvancedOptions"];
}

/*****************************************
 - Handler for dragged files and/or files opened via the Finder
*****************************************/

- (BOOL)application:(NSApplication *)theApplication openFile:(NSString *)filename
{
	BOOL	isDir = NO;
	
	if([[NSFileManager defaultManager] fileExistsAtPath: filename isDirectory: &isDir] && !isDir)
	{
		[self loadScript: filename];
		return(YES);
	}
	return(NO);
}

#pragma mark -


/*****************************************
 - Create a new script and open in default editor
*****************************************/

- (IBAction)newScript:(id)sender
{
	int			i = 0;
	NSString	*tempScript = @"/tmp/PlatypusScript";
	NSArray *defaultInterpreters = [NSArray arrayWithObjects: @"/bin/sh",@"/usr/bin/python",@"/usr/bin/osascript",@"/usr/bin/expect",@"/usr/bin/perl",@"/usr/bin/ruby",@"/usr/bin/tclsh",@"/usr/bin/php", nil];
	
	//put shebang line in the new script text file
	NSString	*shebangStr = [NSString stringWithFormat: @"#!%@\n\n", [defaultInterpreters objectAtIndex: [[scriptTypeRadioButtons selectedCell] tag]]];
	
	//if this is a perl or shell script, we add a commented list of paths to the bundled files 
	if (([[scriptTypeRadioButtons selectedCell] tag] == 0 || [[scriptTypeRadioButtons selectedCell] tag] == 4) && [fileList numFiles] > 0)
	{
		shebangStr = [shebangStr stringByAppendingString: @"# You can access your bundled files at the following paths:\n#\n"];
		for (i = 0; i < [fileList numFiles]; i++)
		{
			if ([[scriptTypeRadioButtons selectedCell] tag] == 0)//shell script
				shebangStr = [shebangStr stringByAppendingString: [NSString stringWithFormat:@"# \"$1/Contents/Resources/%@\"\n", [[fileList getFileAtIndex: i] lastPathComponent]]];
			else if ([[scriptTypeRadioButtons selectedCell] tag] == 4)//perl script
				shebangStr = [shebangStr stringByAppendingString: [NSString stringWithFormat:@"# \"$ARGV[0]/Contents/Resources/%@\"\n", [[fileList getFileAtIndex: i] lastPathComponent]]];
		}
		shebangStr = [shebangStr stringByAppendingString: @"#\n#\n\n"];
	}
	
	//write the default content to the new script
	[shebangStr writeToFile: tempScript atomically: YES];

	//load and edit the script
	[self loadScript: tempScript];
	[self editScript: self];

}

/*****************************************
 - Reveal script in Finder
*****************************************/

- (IBAction)revealScript:(id)sender
{
	if ([[scriptPathTextField stringValue] length] == 0)//make sure the script path is not an empty string
		return;
	//see if file exists
	if ([[NSFileManager defaultManager] fileExistsAtPath: [scriptPathTextField stringValue] ])
		[[NSWorkspace sharedWorkspace] selectFile:[scriptPathTextField stringValue] inFileViewerRootedAtPath:nil];
	else
		[STUtil alert:@"File does not exist" subText: @"No file exists at the specified path"];
}


/*****************************************
 - Open script in external editor
*****************************************/

- (IBAction)editScript:(id)sender
{
	if ([[scriptPathTextField stringValue] length] == 0)//make sure the script path is not an empty string
		return;
	//see if file exists
	if ([[NSFileManager defaultManager] fileExistsAtPath: [scriptPathTextField stringValue] ])
	{
		// if the defaul editor is the built-in editor, we pop down the editor sheet
		if ([[[NSUserDefaults standardUserDefaults] stringForKey:@"DefaultEditor"] isEqualToString: @"Built-In"])
		{
			[self openScriptInBuiltInEditor: [scriptPathTextField stringValue]];
		}
		else // open it in the external application
			[[NSWorkspace sharedWorkspace] openFile: [scriptPathTextField stringValue] withApplication: [[NSUserDefaults standardUserDefaults] stringForKey:@"DefaultEditor"]];
	}
	else
		[STUtil alert:@"File does not exist" subText: @"No file exists at the specified path"];
}


/*****************************************
 - Run the script in Terminal.app
*****************************************/
- (IBAction)runScript:(id)sender
{
	NSTask	*theTask = [[NSTask alloc] init];

	//open Terminal.app
	[[NSWorkspace sharedWorkspace] launchApplication: @"Terminal.app"];

	//the applescript command to run the script in Terminal.app
	NSString *osaCmd = [NSString stringWithFormat: @"tell application \"Terminal\"\n\tdo script \"%@ %@\"\nend tell", [interpreterTextField stringValue], [scriptPathTextField stringValue]];
	
	//initialize task -- we launc the AppleScript via the 'osascript' CLI program
	[theTask setLaunchPath: @"/usr/bin/osascript"];
	[theTask setArguments: [NSArray arrayWithObjects: @"-e", osaCmd, nil]];
	[theTask setStandardError: [NSFileHandle fileHandleWithNullDevice]];
	[theTask setStandardOutput: [NSFileHandle fileHandleWithNullDevice]];
	
	//launch, wait until it's done and then release it
	[theTask launch];
	[theTask waitUntilExit];
	[theTask release];
}

/*****************************************
 - Report on syntax of script
*****************************************/

- (IBAction)checkSyntaxOfScript: (id)sender
{
	NSArray			*defaultInterpreters = [NSArray arrayWithObjects: @"/bin/sh",@"/usr/bin/python",@"/usr/bin/osascript",@"/usr/bin/expect",@"/usr/bin/perl",@"/usr/bin/ruby",@"/usr/bin/tclsh",@"/usr/bin/php", nil];
	NSTask			*interpreter = [[NSTask alloc] init];
	NSPipe			*outputPipe = [NSPipe pipe];
	NSFileHandle	*readHandle;

	if (![[NSFileManager defaultManager] fileExistsAtPath: [scriptPathTextField stringValue] ])//make sure it exists
		return;

	//let's see if the script type is supported for syntax checking
	//if so, we set up the task's launch path as the script interpreter and set the relevant flags and arguments
	switch([[scriptTypeRadioButtons selectedCell] tag])
	{
		case 0: //shell scripts - /bin/sh
			[interpreter setLaunchPath: [defaultInterpreters objectAtIndex: 0]];
			[interpreter setArguments: [NSArray arrayWithObjects: @"-n", [scriptPathTextField stringValue], nil]];
			break;
		case 1: //python scripts -- use bundled syntax checking script
			[interpreter setLaunchPath: [[NSBundle mainBundle] pathForResource: @"pycheck" ofType: @"py"]];
			[interpreter setArguments: [NSArray arrayWithObjects: [scriptPathTextField stringValue], nil]];
			break;
		case 4: //perl scripts - /usr/bin/perl
			[interpreter setLaunchPath: [defaultInterpreters objectAtIndex: 4]];
			[interpreter setArguments: [NSArray arrayWithObjects: @"-c", [scriptPathTextField stringValue], nil]];
			break;
		case 5: //ruby scripts - /usr/bin/ruby
			[interpreter setLaunchPath: [defaultInterpreters objectAtIndex: 5]];
			[interpreter setArguments: [NSArray arrayWithObjects: @"-c", [scriptPathTextField stringValue], nil]];
			break;
		case 7: //php scripts - /usr/bin/php
			[interpreter setLaunchPath: [defaultInterpreters objectAtIndex: 7]];
			[interpreter setArguments: [NSArray arrayWithObjects: @"-l", [scriptPathTextField stringValue], nil]];
			break;
		default:
			[STUtil sheetAlert: @"Syntax Checking Unsupported" subText: @"Syntax checking is not supported for the scripting language you have selected" forWindow: window];
			[interpreter release];
			return;
	}
	
	//direct the output of the task into a file handle for reading
	[interpreter setStandardOutput: outputPipe];
	[interpreter setStandardError: outputPipe];
	readHandle = [outputPipe fileHandleForReading];
	//launch task
	[interpreter launch];
	[interpreter waitUntilExit];
	//get output in string
	NSString *outputStr = [[[NSString alloc] initWithData: [readHandle readDataToEndOfFile] encoding: NSASCIIStringEncoding] autorelease];
	
	if ([outputStr length] == 0) //if the syntax report string is empty, we report syntax as OK
		outputStr = [NSString stringWithString: @"Syntax OK"];
	
	//set syntax checked file's path in syntax chcker window
	[syntaxScriptPathTextField setStringValue: [scriptPathTextField stringValue]];
	[syntaxCheckerTextField setString: outputStr];
	
	[interpreter release];//release the NSTask

	//report the result
	[window setTitle: @"Platypus - Syntax Checker Report"];
	[NSApp beginSheet:	syntaxCheckerWindow
						modalForWindow: window 
						modalDelegate:nil
						didEndSelector:nil
						contextInfo:nil];
	[NSApp runModalForWindow: syntaxCheckerWindow];
	[NSApp endSheet:syntaxCheckerWindow];
    [syntaxCheckerWindow orderOut:self];
}

- (IBAction)closeSyntaxCheckerWindow: (id)sender
{
	[window setTitle: @"Platypus"];
	[NSApp stopModal];
}

#pragma mark -

/*****************************************
 - Create button was pressed: Verify that field values are valid
 - Then put up a sheet for designating location to create application
*****************************************/

- (IBAction)createButtonPressed: (id)sender
{
	if (![self verifyFieldContents])//are there invalid values in the fields?
		return;

	NSSavePanel *sPanel = [NSSavePanel savePanel];
	[sPanel setPrompt:@"Create"];
	[window setTitle: @"Platypus - Select place to create app"];
	
	//run open panel
    [sPanel beginSheetForDirectory:nil file:[appNameTextField stringValue] modalForWindow: window modalDelegate: self didEndSelector: @selector(createApp:returnCode:contextInfo:) contextInfo: nil];

}

/*****************************************
 - generate application bundle from data provided
*****************************************/
- (void)createApp:(NSSavePanel *)sPanel returnCode:(int)result contextInfo:(void *)contextInfo
{
	int	      i;
	NSString *appPath, *contentsPath, *macosPath, *resourcesPath, *lprojPath, *tmpPath = @"/tmp/";
	NSString *execDestinationPath, *infoPlistPath, *iconPath, *bundledFileDestPath, *progressBarNibDestPath;
	NSString *execPath, *bundledFilePath, *progressBarNibPath;
	NSString *scriptFilePath, *pkgInfoPath, *appSettingsPlistPath;
	NSString *appName;
	NSString *infoPlistStrings;
	NSBundle *platypusBundle = [NSBundle mainBundle];
	NSMutableDictionary	*appSettingsPlist;
	NSFileManager *fileManager = [NSFileManager defaultManager];
	
	//restore window title
	[window setTitle: @"Platypus"];
	
	// if user pressed cancel, we do nothing
	if (result != NSOKButton) 
		return;
	
	// we begin by appending .app to the user-specified app name in dialog, unless it already has one
	appPath = [sPanel filename];
	if (![appPath hasSuffix:@".app"])
		appPath = [appPath stringByAppendingString:@".app"];
	
	
	
	/////////////////////////// MAKE SURE EVERYTHING IS OK /////////////////////////////////////
	
	// make sure we can write to /tmp/
	if (![fileManager isWritableFileAtPath: tmpPath])
	{
		[STUtil fatalAlert: @"Unable to write temporary files" subText: @"Could not write to the /tmp/ directory.  Make sure this directory exists and that you have write privileges."]; 
		return;
	}
	//make sure we have write privileges for the selected directory
	if (![fileManager isWritableFileAtPath: [appPath stringByDeletingLastPathComponent]])
	{
		[STUtil alert: @"Unable to create app" subText: @"You don't have permission to modify the directory you selected.  Please selected another directory in which to create the application."];
		return;
	}
	
	//check if app already exists, and if so, prompt if to replace
	if ([fileManager fileExistsAtPath: appPath])
	{
		if (NO == [STUtil proceedWarning: @"Application already exists" subText: @"An application with this name already exists in the location you specified.  Do you wish to overwrite it?"])
			return;

		if ([fileManager isDeletableFileAtPath: appPath])
			[fileManager removeFileAtPath: appPath handler: NULL];
		else
		{
			[STUtil fatalAlert: @"Failed to overwrite" subText: [NSString stringWithFormat: @"Could not overwrite %@.  Make sure that you have write privileges.", appPath]]; 
			return;
		}
	}
	
	
	////////////////////////// CREATE THE FOLDER HIERARCHY /////////////////////////////////////
	
	// we begin by creating the application bundle in /tmp/
	
	//Application.app bundle in /tmp
	tmpPath = [tmpPath stringByAppendingString: [appPath lastPathComponent]];
	[fileManager createDirectoryAtPath: tmpPath attributes:nil];
	
	//.app/Contents
	contentsPath = [tmpPath stringByAppendingString:@"/Contents"];
	[fileManager createDirectoryAtPath: contentsPath attributes:nil];
	
	//.app/Contents/MacOS
	macosPath = [contentsPath stringByAppendingString:@"/MacOS"];
	[fileManager createDirectoryAtPath: macosPath attributes:nil];
	
	//.app/Contents/Resources
	resourcesPath = [contentsPath stringByAppendingString:@"/Resources"];
	[fileManager createDirectoryAtPath: resourcesPath attributes:nil];
	
	//.app/Contents/Resources/en.lproj 
	lprojPath = [resourcesPath stringByAppendingString:@"/en.lproj"];
	[fileManager createDirectoryAtPath: lprojPath attributes:nil];
	
	//.app/Contents/PkgInfo
	pkgInfoPath = [contentsPath stringByAppendingString:@"/PkgInfo"];
	[[NSString stringWithString: [NSString stringWithFormat: @"APPL%@", [signatureTextField stringValue]]] writeToFile: pkgInfoPath atomically: YES];
	
	////////////////////////// COPY FILES TO THE APP BUNDLE //////////////////////////////////
	
		//copy exec file
		//.app/Contents/Resources/MacOS/Exec
		appName = [STUtil cutSuffix: [appPath lastPathComponent]];
		execPath = [platypusBundle pathForResource:@"exec" ofType:nil];
		execDestinationPath = [macosPath stringByAppendingString:@"/"];
		execDestinationPath = [execDestinationPath stringByAppendingString: appName]; 
		[fileManager copyPath:execPath toPath:execDestinationPath handler:nil];
		
		//copy nib file to app bundle
		//.app/Contents/Resources/en.lproj/MainMenu.nib
		progressBarNibPath = [platypusBundle pathForResource:@"MainMenu.nib" ofType:nil];
		progressBarNibDestPath = [lprojPath stringByAppendingString:@"/MainMenu.nib"];
		[fileManager copyPath:progressBarNibPath toPath:progressBarNibDestPath handler:nil];
			
		//create InfoPlist.strings file
		//.app/Contents/Resources/en.lproj/InfoPlist.strings
		infoPlistStrings = [NSString stringWithFormat:
							@"CFBundleName = \"%@\";\nCFBundleShortVersionString = \"%@\";\nCFBundleGetInfoString = \"%@ version %@ Copyright %d %@\";\nNSHumanReadableCopyright = \"Copyright %d %@.\";",  
											  appName, [versionTextField stringValue], appName, [versionTextField stringValue], [[NSCalendarDate calendarDate] yearOfCommonEra], [authorTextField stringValue], [[NSCalendarDate calendarDate] yearOfCommonEra], [authorTextField stringValue]];
		[infoPlistStrings writeToFile:  [lprojPath stringByAppendingString:@"/InfoPlist.strings"] atomically: YES];
		
		// create script file in app bundle
		//.app/Contents/Resources/script
		//.app/Contents/Resources/.script
		NSString *scriptString = [NSString stringWithContentsOfFile: [scriptPathTextField stringValue]];
		if ([encryptCheckbox state] == YES)
		{
			scriptFilePath = [resourcesPath stringByAppendingString:@"/.script"];
			[[SillyStringEncrypt sillyEncryptString: scriptString] writeToFile: scriptFilePath atomically: YES];
			[[NSString stringWithString: @""] writeToFile: [resourcesPath stringByAppendingString:@"/script"] atomically: YES];
		}
		else
		{
			scriptFilePath = [resourcesPath stringByAppendingString:@"/script"];
			[scriptString writeToFile: scriptFilePath atomically: YES];
			[[NSString stringWithString: @""] writeToFile: [resourcesPath stringByAppendingString:@"/.script"] atomically: YES];
		}
		
		//create AppSettings.plist file
		//.app/Contents/Resources/AppSettings.plist
		appSettingsPlist = [NSMutableDictionary dictionaryWithCapacity: 40];
		[appSettingsPlist setObject: [NSNumber numberWithBool:[rootPrivilegesCheckbox state]] forKey:@"RequiresAdminPrivileges"];
		[appSettingsPlist setObject: [NSNumber numberWithBool:[isDroppableCheckbox state]] forKey:@"IsDroppable"];
		[appSettingsPlist setObject: [NSNumber numberWithBool:[remainRunningCheckbox state]] forKey:@"RemainRunningAfterCompletion"];
		[appSettingsPlist setObject: [NSNumber numberWithBool:[encryptCheckbox state]] forKey:@"EncryptAndChecksum"];
		if ([encryptCheckbox state])//it is checked
			[appSettingsPlist setObject: [STChecksum getChecksumForFileAsString: scriptFilePath] forKey: @"ScriptChecksum"];
		[appSettingsPlist setObject: [[[[outputTypeRadioButtons selectedCell] title] componentsSeparatedByString:@" "] componentsJoinedByString:@""] forKey:@"OutputType"];
		[appSettingsPlist setObject: [interpreterTextField stringValue] forKey:@"ScriptInterpreter"];
		[appSettingsPlist setObject: [NSString stringWithFormat: @"%s", PROGRAM_STAMP] forKey: @"Creator"];
		appSettingsPlistPath = [resourcesPath stringByAppendingString:@"/AppSettings.plist"];
		[appSettingsPlist writeToFile: appSettingsPlistPath atomically: YES];//write it 
						
		//create icon
		//.app/Contents/Resources/appIcon.icns
		iconPath = [resourcesPath stringByAppendingString:@"/appIcon.icns"];
		if ([iconControl usesIcnsFile] == YES)
			[fileManager copyPath: [iconControl getIcnsFilePath] toPath: iconPath handler:nil];
		else
			[iconControl writeIconToPath: iconPath];
		
		//create Info.plist file
		//.app/Contents/Info.plist
		infoPlistPath = [contentsPath stringByAppendingString:@"/Info.plist"];
		NSMutableDictionary *infoPlist = [self getInfoPropertyListDictionary: appName isDroppable: [isDroppableCheckbox state] inBackground: [showInDockCheckbox state] ];
		[infoPlist writeToFile: infoPlistPath atomically: YES];
		
		//copy files in file list to the Resources folder
		//.app/Contents/Resources/*
		for (i = 0; i < [fileList numFiles]; i++)
		{
			bundledFilePath = [fileList getFileAtIndex: i];
			bundledFileDestPath = [resourcesPath stringByAppendingString:@"/"];
			bundledFileDestPath = [bundledFileDestPath stringByAppendingString: [bundledFilePath lastPathComponent]];
			[fileManager copyPath: bundledFilePath toPath: bundledFileDestPath handler:nil];
		}
		
		////////////////////////////////// COPY APP OVER TO FINAL DESTINATION /////////////////////////////////
		
		// we've now created the application bundle in /tmp/
		// now it's time to move it to the destination specified by the user
		
		[fileManager movePath: tmpPath toPath: appPath handler:nil];//move
		if ([[NSFileManager defaultManager] fileExistsAtPath:appPath]) //if move was a success
		{
			// note that the file system has changed
			[[NSWorkspace sharedWorkspace] noteFileSystemChanged: appPath];
		
			if ([[NSUserDefaults standardUserDefaults] boolForKey:@"RevealApplicationWhenCreated"])// reveal in Finder
				[[NSWorkspace sharedWorkspace] selectFile:appPath inFileViewerRootedAtPath:nil];
		}
		else
			[STUtil alert: @"Creation failed" subText: [NSString stringWithFormat: @"Platypus failed to create an application at %@.  Make sure you have the necessary write privileges.", appPath]];
}



/*****************************************
 - Make sure that all fields contain valid values
*****************************************/

- (BOOL)verifyFieldContents
{
	BOOL			isDir;
	//file manager
	NSFileManager *fileManager = [NSFileManager defaultManager];

	//script path
	if ([[appNameTextField stringValue] length] == 0)//make sure a name has been assigned
	{
		[STUtil sheetAlert:@"Invalid Application Name" subText: @"You must specify a name for your application" forWindow: window];
		return NO;
	}

	//script path
	if (([fileManager fileExistsAtPath: [scriptPathTextField stringValue] isDirectory: &isDir] == NO) || isDir)//make sure script exists and isn't a folder
	{
		[STUtil sheetAlert:@"Invalid Script Path" subText: @"No file exists at the script path you have specified" forWindow: window];
		return NO;
	}
	//interpreter
	if ([fileManager fileExistsAtPath: [interpreterTextField stringValue]] == NO)//make sure interpreter exists
	{
		if (NO == [STUtil proceedWarning: @"Invalid Interpreter" subText: @"The specified interpreter does not exist on this system.  Do you wish to proceed anyway?"])
			return NO;
	}
	//make sure typeslist contains valid values
	if ([typesList numTypes] <= 0 && [isDroppableCheckbox state] == YES)
	{
		[STUtil sheetAlert:@"Invalid Types List" subText: @"The app has been set to be droppable but no file types are set.  Please modify the Types list to correct this." forWindow: window];
		return NO;
	}
	//make sure the signature is 4 characters
	if ([[signatureTextField stringValue] length] != 4)
	{
		[STUtil sheetAlert:@"Invalid App Signature" subText: @"The signature set for the application is invalid.  An app's signature must consist of four upper or lowercase ASCII characters." forWindow: window];
		return NO;
	}
	
	//make sure we have an icon
	if ([iconControl getImage] == NULL)
	{
		[STUtil sheetAlert:@"Missing Icon" subText: @"You must set an icon for your application." forWindow: window];
		return NO;
	}
	
	return YES;
}


/*****************************************
 - Called when script type radio button is pressed
*****************************************/

- (IBAction)scriptTypeSelected:(id)sender
{
	[self setScriptType: [[sender selectedCell] tag] ];
}

/*****************************************
 - Updates data in interpreter, icon and script type radio buttons
*****************************************/

- (void)setScriptType: (int)typeNum
{
	// set the script type based on the number which identifies each type
	NSArray *defaultInterpreters = [NSArray arrayWithObjects: @"/bin/sh",@"/usr/bin/python",@"/usr/bin/osascript",@"/usr/bin/expect",@"/usr/bin/perl",@"/usr/bin/ruby",@"/usr/bin/tclsh",@"/usr/bin/php", nil];
	[interpreterTextField setStringValue: [defaultInterpreters objectAtIndex: typeNum ] ];
	[self controlTextDidChange: NULL];
	if ([iconControl hasCustomIcon] == NO)
		[iconControl setAppIconForType: typeNum];
	[scriptTypeRadioButtons selectCellWithTag: typeNum];
}

/*****************************************
 - Parse the Shebang line (#!) to get the interpreter for the script
   We're doing this by getting a C string.  Apple's NSString doesn't
   seem to be any more convenient, and this seems to work just fine
*****************************************/

- (NSString *)getInterpreterFromShebang: (NSString *)path
{
	NSString	*script, *firstLine, *shebang, *interpreterCmd, *theInterpreter;
	NSArray		*lines, *words;
	
	// get the first line of the script
	script = [NSString stringWithContentsOfFile: path encoding: NSASCIIStringEncoding error: nil];
	lines = [script componentsSeparatedByString: @"\n"];
	firstLine = [lines objectAtIndex: 0];
	
	// if the first line of the script is shorter than 2 chars, it can't possibly be a shebang line
	if ([firstLine length] <= 2)
		return @"";
	
	// get first two characters of first line
	shebang = [firstLine substringToIndex: 2]; // first two characters should be #!
	if (![shebang isEqualToString: @"#!"])
		return @"";
	
	// get everything that follows after the #!
	// seperate it by whitespaces, in order not to get also the params to the interpreter
	interpreterCmd = [firstLine substringFromIndex: 2];
	words = [interpreterCmd componentsSeparatedByString: @" "];
	theInterpreter = [words objectAtIndex: 0];
	return (theInterpreter);
}


/*****************************************
 - Open sheet to select script to load
*****************************************/

- (IBAction)selectScript:(id)sender
{
	//create open panel
    NSOpenPanel *oPanel = [NSOpenPanel openPanel];
	[oPanel setPrompt:@"Select"];
    [oPanel setAllowsMultipleSelection:NO];
	[oPanel setCanChooseDirectories: NO];
	
	[window setTitle: @"Platypus - Select a script"];
	
	//run open panel
    [oPanel beginSheetForDirectory:nil file:nil types:nil modalForWindow: window modalDelegate: self didEndSelector: @selector(selectScriptPanelDidEnd:returnCode:contextInfo:) contextInfo: nil];
		
}

- (void)selectScriptPanelDidEnd:(NSOpenPanel *)oPanel returnCode:(int)returnCode contextInfo:(void *)contextInfo
{
	if (returnCode == NSOKButton)
		[self loadScript: [oPanel filename]];
	[window setTitle: @"Platypus"];
}

/*****************************************
 - Loads script data into platypus window
*****************************************/

- (void)loadScript:(NSString *)filename
{
	NSString	*shebangInterpreter;
	int			i;

	//make sure file we're loading actually exists
	if (![[NSFileManager defaultManager] fileExistsAtPath: filename])
		return;

	//set script path
	[scriptPathTextField setStringValue: filename];

	//set app name
	NSString *appName = [STUtil cutSuffix: [filename lastPathComponent]];
	[appNameTextField setStringValue: appName];
	
	//read shebang line
	shebangInterpreter = [self getInterpreterFromShebang: filename];
	
	//if no interpreter can be retrieved from shebang line
	if ([shebangInterpreter caseInsensitiveCompare: @""] == NSOrderedSame)
	{
		//try to determine type from suffix
		[self setScriptType: (int)[self getFileTypeFromSuffix: filename] ];
	}
	else
	{
		//see if interpreter matches a preset
		NSArray *defaultInterpreters = [NSArray arrayWithObjects: @"/bin/sh",@"/usr/bin/python",@"/usr/bin/osascript",@"/usr/bin/expect",
																  @"/usr/bin/perl",@"/usr/bin/ruby",@"/usr/bin/tclsh",@"/usr/bin/php", nil];
		for (i = 0; i < [defaultInterpreters count]; i++)
		{
			if ([shebangInterpreter caseInsensitiveCompare: [defaultInterpreters objectAtIndex: i]] == NSOrderedSame)
				[self setScriptType: i];
		}
		
		//set shebang interpreter into interpreter field
		[interpreterTextField setStringValue: shebangInterpreter ];
	}
	
	[self controlTextDidChange: NULL];
	
	//add to open recent menu
	if (![recentItems containsObject: filename])
	{
		if ([recentItems count] == 8)
			[recentItems removeObjectAtIndex: 0];

		[recentItems addObject: filename];
		[self constructOpenRecentMenu];
	}
}

- (void)loadApp:(NSString *)path
{
	//verify that this is an application
	if (![path hasSuffix: @"app"])
	{
		[STUtil alert: @"Not Application" subText: @"The item selected for loading is not an appliction"]; 
		return;
	}
	
	//verify that this is a Platypus-generated application
	NSString *appSettingsPlistPath = [NSString stringWithFormat: @"%@/Contents/Resources/AppSettings.plist", path];
	if (![[NSFileManager defaultManager] fileExistsAtPath: appSettingsPlistPath])
	{
		[STUtil alert: @"Invalid Platypus Application" subText: @"The item selected for loading is either damaged or not a Platypus appliction."]; 
		return;
	}
	
	//OK, let's load script
	NSString *scriptPath = [NSString stringWithFormat: @"%@/Contents/Resources/script", path];
	[self loadScript: scriptPath];
	[self controlTextDidChange: NULL];
	
	// app settings applied
	NSDictionary *appSettings = [NSDictionary dictionaryWithContentsOfFile: appSettingsPlistPath];
		// if it's encrypted, we can't load it
		if ([[appSettings objectForKey: @"EncryptAndChecksum"] boolValue] == YES)
		{
			[STUtil alert: @"Encrypted Application" subText: @"The item selected for loading is an encrypted Platypus application and cannot be loaded."]; 
			return;
		}
		
		//configure controls in Platypus window according to settings in AppSettings.plist
		[isDroppableCheckbox setIntValue: [[appSettings objectForKey: @"IsDroppable"] boolValue]];
		[self isDroppableWasClicked: self];
		[remainRunningCheckbox setIntValue: [[appSettings objectForKey: @"RemainRunningAfterCompletion"] boolValue]];
		[rootPrivilegesCheckbox setIntValue: [[appSettings objectForKey: @"RequiresAdminPrivileges"] boolValue]];
		[interpreterTextField setStringValue: [appSettings objectForKey: @"ScriptInterpreter"]];
		if ([[appSettings objectForKey: @"OutputType"] isEqualToString: @"None"])
			[outputTypeRadioButtons selectCellWithTag: 0];
		else if ([[appSettings objectForKey: @"OutputType"] isEqualToString: @"ProgressBar"])
			[outputTypeRadioButtons selectCellWithTag: 1];
		else
			[outputTypeRadioButtons selectCellWithTag: 2];
	
	//Now, let's load the info.plist file
	NSDictionary *infoPlist = [NSDictionary dictionaryWithContentsOfFile: [NSString stringWithFormat: @"%@/Contents/Info.plist", path]];
	if (infoPlist == NULL) 
	{ 
		[STUtil alert: @"Corrupt Application Bundle" subText: @"Couldn't find Info.plist within application bundle."];
		return; 
	}
	[appNameTextField setStringValue: [infoPlist objectForKey: @"CFBundleDisplayName"]];
	[bundleIdentifierTextField setStringValue: [infoPlist objectForKey: @"CFBundleIdentifier"]];
	[versionTextField setStringValue: [infoPlist objectForKey: @"CFBundleVersion"]];
	[signatureTextField setStringValue: [infoPlist objectForKey: @"CFBundleSignature"]];
	[showInDockCheckbox setIntValue: [[infoPlist objectForKey: @"LSUIElement"] intValue]];
	
	//load icon
	NSImage *icon = [[[NSImage alloc] initWithContentsOfFile: [NSString stringWithFormat: @"%@/Contents/Resources/appIcon.icns", path]] autorelease];
	[iconControl setImage: icon];
	[iconControl iconDidChange: self];
	
	// and now for the bundled files
	/*NSString *file;
	NSDirectoryEnumerator *dirEnum = [[NSFileManager defaultManager] enumeratorAtPath: [NSString stringWithFormat: @"%@/Contents/Resources/",path]];
	while (file = [dirEnum nextObject]) 
	{
		// if it's not one of the standard platypus app bundle files, it must be a bundled file, right?
		if (![file isEqualToString: @"appIcon.icns"] && ![file isEqualToString: @"en.lproj"] && 
		    ![file isEqualToString: @"English.lproj"] && ![file isEqualToString: @"AppSettings.plist"]) 
		{
			[fileList addFile: [NSString stringWithFormat: @"%@/Contents/Resources/%@", path, file]];
		}
	}*/
}

/*****************************************
 - Toggles between advanced options mode
*****************************************/

- (IBAction)toggleAdvancedOptions:(id)sender
{
	#define		kWindowExpansionHeight  332
	NSRect winRect = [window frame];

	if ([showAdvancedArrow state] == NSOffState)
	{
		winRect.origin.y += kWindowExpansionHeight;
		winRect.size.height -= kWindowExpansionHeight;
		[showOptionsTextField setStringValue: @"Show Advanced Options"];
		[toggleAdvancedMenuItem setTitle: @"Show Advanced Options"];
		[window setFrame: winRect display:TRUE animate: TRUE];
	}
	else if ([showAdvancedArrow state] == NSOnState)
	{
		winRect.origin.y -= kWindowExpansionHeight;
		winRect.size.height += kWindowExpansionHeight;
		[showOptionsTextField setStringValue: @"Hide advanced options"];
		[toggleAdvancedMenuItem setTitle: @"Hide Advanced Options"];
		[window setFrame: winRect display:TRUE animate: TRUE];
	}
}

/*****************************************
 - called when [X] Is Droppable is pressed
*****************************************/
- (IBAction)isDroppableWasClicked:(id)sender
{
	//register the data source for the types and suffix lists
	[self setDefaultTypes: self];
	[typesListDataBrowser setDataSource: typesList];
	[typesListDataBrowser reloadData];
	[suffixListDataBrowser setDataSource: suffixList];
	[suffixListDataBrowser reloadData];

	[editTypesButton setHidden: ![isDroppableCheckbox state]];
	[editTypesButton setEnabled: [isDroppableCheckbox state]];
}

/*****************************************
 - called when (Clear) button is pressed -- restores fields to startup values
*****************************************/
- (IBAction)clearAllFields:(id)sender
{
	//clear all text field to start value
	[appNameTextField setStringValue: @""];
	[scriptPathTextField setStringValue: @""];
	[versionTextField setStringValue: @"1.0"];
	[signatureTextField setStringValue: @"????"];
	
	[bundleIdentifierTextField setStringValue: [[NSUserDefaults standardUserDefaults] objectForKey:@"DefaultBundleIdentifierPrefix"]];
	[authorTextField setStringValue: [[NSUserDefaults standardUserDefaults] objectForKey:@"DefaultAuthor"]];
	
	//uncheck all options
	[isDroppableCheckbox setIntValue: 0];
	[self isDroppableWasClicked: isDroppableCheckbox];
	[encryptCheckbox setIntValue: 0];
	[rootPrivilegesCheckbox setIntValue: 0];
	[remainRunningCheckbox setIntValue: 0];
	[showInDockCheckbox setIntValue: 0];
	
	//clear file list
	[fileList clearFileList: self];
	
	//clear suffix and types lists to default values
	[self setDefaultTypes: self];
	
	//set environment variables list to default
	[envControl resetDefaults: self];
	
	//set script type
	[self setScriptType: 0];
	[iconControl setAppIconForType: 0];
	
	//set output type
	[outputTypeRadioButtons selectCellWithTag: 0];
	//[self outputTypeChanged: outputTypeRadioButtons];
	
	//update button status
	[self controlTextDidChange: NULL];
}


- (NSString *)commandLineStringFromSettings
{
	int i;
	NSString *checkboxParamStr = @"";
	NSArray *scriptTypes = [NSArray arrayWithObjects: @"Shell", @"Python", @"AppleScript", @"Expect", @"Perl", @"Ruby", @"Tcl", @"PHP", nil];
	NSArray *outputTypes = [NSArray arrayWithObjects: @"None", @"ProgressBar", @"TextWindow", nil];
	
	if ([rootPrivilegesCheckbox intValue])
		checkboxParamStr = [checkboxParamStr stringByAppendingString: @"A"];
	if ([encryptCheckbox intValue])
		checkboxParamStr = [checkboxParamStr stringByAppendingString: @"S"];
	if ([isDroppableCheckbox intValue])
		checkboxParamStr = [checkboxParamStr stringByAppendingString: @"D"];
	if ([showInDockCheckbox intValue])
		checkboxParamStr = [checkboxParamStr stringByAppendingString: @"B"];
	if ([remainRunningCheckbox intValue])
		checkboxParamStr = [checkboxParamStr stringByAppendingString: @"R"];
	
	if ([checkboxParamStr length] != 0)
		checkboxParamStr = [NSString stringWithFormat: @"-%@ ", checkboxParamStr];
	
	//create bundled files string
	NSString *bundledFilesCmdString = @"";
	NSArray *bundledFiles = [fileList getFilesArray];
	for (i = 0; i < [bundledFiles count]; i++)
	{
		bundledFilesCmdString = [bundledFilesCmdString stringByAppendingString: [NSString stringWithFormat: @"-f '%@'", [bundledFiles objectAtIndex: i]]];
	}
	
	NSString *commandStr = [NSString stringWithFormat: 
	@"/usr/local/bin/platypus %@-a '%@' -t '%@' -o '%@' -u '%@'-i '%@' -V '%@' -s '%@' -I '%@' %@ '%@' 'MyApp.app'",
	checkboxParamStr,
	[appNameTextField stringValue],
	[scriptTypes objectAtIndex: [[scriptTypeRadioButtons selectedCell] tag]],
	[outputTypes objectAtIndex: [[outputTypeRadioButtons selectedCell] tag]],
	[authorTextField stringValue],
	[interpreterTextField stringValue],
	[versionTextField stringValue],
	[signatureTextField stringValue], 
	[bundleIdentifierTextField stringValue],
	bundledFilesCmdString,
	[scriptPathTextField stringValue],
	nil];

	return commandStr;
}

/*****************************************
 - Generate shell command and display in text field
*****************************************/

- (IBAction)showCommandLineString: (id)sender
{
	[commandTextField setFont:[NSFont userFixedPitchFontOfSize: 10.0]];
	[commandTextField setString: [self commandLineStringFromSettings]];

	[window setTitle: @"Platypus - Shell Command String"];
	[NSApp beginSheet:	commandWindow
						modalForWindow: window 
						modalDelegate:nil
						didEndSelector:nil
						contextInfo:nil];
	[NSApp runModalForWindow: commandWindow];
	[NSApp endSheet:commandWindow];
    [commandWindow orderOut:self];
}

- (IBAction)closeCommandWindow: (id)sender
{
	[window setTitle: @"Platypus"];
	[NSApp stopModal];
}


#pragma mark -

/*****************************************
 - Generate dictionary for Info.plist in app bundle
*****************************************/

- (NSMutableDictionary *)getInfoPropertyListDictionary: (NSString *)appName isDroppable: (BOOL)droppable inBackground: (BOOL)background
{	
	NSMutableDictionary *infoPlist = [NSMutableDictionary dictionaryWithObjectsAndKeys: 
								@"English", @"CFBundleDevelopmentRegion",
								appName, @"CFBundleExecutable", 
								appName, @"CFBundleName",
								appName, @"CFBundleDisplayName",
								[NSString stringWithFormat: @"%@ %@ Copyright %d %@", appName, [versionTextField stringValue], [[NSCalendarDate calendarDate] yearOfCommonEra], NSFullUserName() ], @"CFBundleGetInfoString", 
								[NSString stringWithFormat: @"%@ %@ Copyright %d %@", appName, [versionTextField stringValue], [[NSCalendarDate calendarDate] yearOfCommonEra], NSFullUserName() ], @"NSHumanReadableCopyright", 
								@"appIcon.icns", @"CFBundleIconFile",  
								[versionTextField stringValue], @"CFBundleVersion",
								[versionTextField stringValue], @"CFBundleShortVersionString", 
								[bundleIdentifierTextField stringValue], @"CFBundleIdentifier",  
								[NSNumber numberWithBool: background], @"LSUIElement",
								@"6.0", @"CFBundleInfoDictionaryVersion",
								@"APPL", @"CFBundlePackageType",
								[signatureTextField stringValue], @"CFBundleSignature",
								[NSNumber numberWithBool: NO], @"LSHasLocalizedDisplayName",
								[envControl environmentDictionary], @"LSEnvironment",
								[NSNumber numberWithBool: NO], @"NSAppleScriptEnabled",
								@"MainMenu", @"NSMainNibFile",  
								@"NSApplication", @"NSPrincipalClass",  nil];
		
	if (droppable)
	{
		NSMutableDictionary	*typesAndSuffixesDict = [NSMutableDictionary dictionaryWithObjectsAndKeys:
						[suffixList getSuffixArray], @"CFBundleTypeExtensions",//extensions
						[typesList getTypesArray], @"CFBundleTypeOSTypes",//os types
						[[appFunctionRadioButtons selectedCell] title], @"CFBundleTypeRole", nil];//viewer or editor?
						
		[infoPlist setObject: [NSArray arrayWithObject: typesAndSuffixesDict] forKey: @"CFBundleDocumentTypes"];
	}
		
	return(infoPlist);
}


/*****************************************
 - Determine script type based on a file's suffix
*****************************************/

- (int)getFileTypeFromSuffix: (NSString *)fileName
{
	if ([fileName hasSuffix: @".sh"])
		return 0;
	else if ([fileName hasSuffix: @".py"])
		return 1;
	else if ([fileName hasSuffix: @".scpt"] || [fileName hasSuffix: @".applescript"])
		return 2;
	else if ([fileName hasSuffix: @".exp"] || [fileName hasSuffix: @".expect"])
		return 3;
	else if ([fileName hasSuffix: @".pl"] || [fileName hasSuffix: @".perl"])
		return 4;
	else if ([fileName hasSuffix: @".rb"] || [fileName hasSuffix: @".rbx"])
		return 5;
	else if ([fileName hasSuffix: @".tcl"])
		return 6;
	else if ([fileName hasSuffix: @".php"])
		return 7;
	else
		return 0;
}

/*****************************************
 - //return the bundle identifier for the application
*****************************************/
- (NSString *)generateBundleIdentifier
{
	NSString	*bundleId;
	//The format is "org.username.appname"
	bundleId = [NSString stringWithFormat: @"%@%@", [[NSUserDefaults standardUserDefaults] stringForKey:@"DefaultBundleIdentifierPrefix"], [appNameTextField stringValue]];
	bundleId = [[bundleId componentsSeparatedByString:@" "] componentsJoinedByString:@""];//no spaces
	return(bundleId);
}

#pragma mark -
/*****************************************
 - Set controls according to data in NSUserDefaults
*****************************************/
- (IBAction)showPrefs:(id)sender
{	
	if ([prefsWindow isVisible])// if prefs are already visible we just bring the window front
	{
		[prefsWindow makeKeyAndOrderFront: sender];
		return;
	}
	
	// set controls according to NSUserDefaults
	[parseShebangCheckbox setState: [[NSUserDefaults standardUserDefaults] boolForKey:@"ParseShebangLineForInterpreter"]];
	[revealAppCheckbox setState: [[NSUserDefaults standardUserDefaults] boolForKey:@"RevealApplicationWhenCreated"]];
	[defaultEditorMenu setTitle: [[NSUserDefaults standardUserDefaults] stringForKey:@"DefaultEditor"]];
	[defaultAuthorTextField setStringValue: [[NSUserDefaults standardUserDefaults] stringForKey:@"DefaultAuthor"]];
	[defaultBundleIdentifierTextField setStringValue: [[NSUserDefaults standardUserDefaults] stringForKey:@"DefaultBundleIdentifierPrefix"]];

	//set icons for editor menu
	[self setIconsForEditorMenu];

	//center and show prefs window
	[prefsWindow center];
	[prefsWindow makeKeyAndOrderFront: sender];
}
/*****************************************
 - Set the icons for the menu items in the Editors list
*****************************************/
- (void)setIconsForEditorMenu
{
	int i;
	NSSize	smallIconSize = { 16, 16 };

	for (i = 0; i < [defaultEditorMenu numberOfItems]; i++)
	{
		if ([[[defaultEditorMenu itemAtIndex: i] title] isEqualToString: @"Built-In"] == YES)
		{
			NSImage *icon = [NSImage imageNamed: @"platypus"];
			[icon setSize: smallIconSize];
			[[defaultEditorMenu itemAtIndex: i] setImage: icon];
		}
		else if ([[[defaultEditorMenu itemAtIndex: i] title] isEqualToString: @"Select..."] == NO && [[[defaultEditorMenu itemAtIndex: i] title] length] > 0)
		{
			NSString *appPath = [[NSWorkspace sharedWorkspace] fullPathForApplication: [[defaultEditorMenu itemAtIndex: i] title]];
			NSImage *icon = [[NSWorkspace sharedWorkspace] iconForFile: appPath];
			[icon setSize: smallIconSize];
			[[defaultEditorMenu itemAtIndex: i] setImage: icon];
		}
	}
}
/*****************************************
 - Set NSUserDefaults according to control settings
*****************************************/
- (IBAction)applyPrefs:(id)sender
{
	[[NSUserDefaults standardUserDefaults] setBool: [parseShebangCheckbox state] forKey:@"ParseShebangLineForInterpreter"];
	[[NSUserDefaults standardUserDefaults] setBool: [revealAppCheckbox state]  forKey:@"RevealApplicationWhenCreated"];
	[[NSUserDefaults standardUserDefaults] setObject: [defaultEditorMenu titleOfSelectedItem]  forKey:@"DefaultEditor"];
	//make sure bundle identifier ends with a '.'
	if ([[defaultBundleIdentifierTextField stringValue] characterAtIndex: [[defaultBundleIdentifierTextField stringValue]length]-1] != '.')
		
		[[NSUserDefaults standardUserDefaults] setObject: [[defaultBundleIdentifierTextField stringValue] stringByAppendingString: @"."]  forKey:@"DefaultBundleIdentifierPrefix"];
	else
		[[NSUserDefaults standardUserDefaults] setObject: [defaultBundleIdentifierTextField stringValue]  forKey:@"DefaultBundleIdentifierPrefix"];
	[[NSUserDefaults standardUserDefaults] setObject: [defaultAuthorTextField stringValue]  forKey:@"DefaultAuthor"];
	
	[prefsWindow performClose: sender];
}


/*****************************************
 - Restore prefs to their default value
*****************************************/
- (IBAction)restoreDefaultPrefs:(id)sender
{
	[parseShebangCheckbox setState: YES];
	[revealAppCheckbox setState: NO];
	[defaultEditorMenu setTitle: @"Built-In"];
	[defaultAuthorTextField setStringValue: NSFullUserName()];
	NSString *bundleId = [NSString stringWithFormat: @"org.%@.", NSUserName()];
	bundleId = [[bundleId componentsSeparatedByString:@" "] componentsJoinedByString:@""];//no spaces
	[defaultBundleIdentifierTextField setStringValue: bundleId];
}


/*****************************************
 - For selecting any application as the external editor for script
*****************************************/
- (IBAction) selectScriptEditor:(id)sender
{
	int			result;
	NSString	*editorName;
	
	//create open panel
    NSOpenPanel *oPanel = [NSOpenPanel openPanel];
	[oPanel setTitle: @"Select Editor"];
    [oPanel setAllowsMultipleSelection:NO];
	[oPanel setCanChooseDirectories: NO];
	
	//run open panel
    result = [oPanel runModalForDirectory:nil file:nil types: [NSArray arrayWithObject:@"app"]];
    if (result == NSOKButton) 
	{
		//set app name minus .app suffix
		editorName = [STUtil cutSuffix: [[oPanel filename] lastPathComponent]];
		[defaultEditorMenu setTitle: editorName];
		[self setIconsForEditorMenu];
	}
	else
		[defaultEditorMenu setTitle: [[NSUserDefaults standardUserDefaults] stringForKey:@"DefaultEditor"]];
}

#pragma mark -

/*****************************************
 - Dragging and dropping for Platypus window
*****************************************/

- (BOOL)performDragOperation:(id <NSDraggingInfo>)sender
{
	NSPasteboard	*pboard = [sender draggingPasteboard];
	NSString		*filename;
	BOOL			isDir = FALSE;

    if ( [[pboard types] containsObject:NSFilenamesPboardType] ) 
	{
        NSArray *files = [pboard propertyListForType:NSFilenamesPboardType];
		filename = [files objectAtIndex: 0];//we only load the first dragged item
		if ([[NSFileManager defaultManager] fileExistsAtPath: filename isDirectory:&isDir] && !isDir)
		{
			[self loadScript: filename];
			return YES;
		}
		else if ([filename hasSuffix: @"app"])
		{
			[self loadApp: filename];
			return YES;
		}
	}
	return NO;
}


- (void)tableViewSelectionDidChange:(NSNotification *)aNotification
{
	int i;
	int selected = 0;
	NSIndexSet *selectedItems;
	
	if ([aNotification object] == suffixListDataBrowser || [aNotification object] == NULL)
	{
		selectedItems = [suffixListDataBrowser selectedRowIndexes];
		for (i = 0; i < [suffixList numSuffixes]; i++)
		{
			if ([selectedItems containsIndex: i])
				selected++;
		}
		
		//update button status
		if (selected == 0)
			[removeSuffixButton setEnabled: NO];
		else
			[removeSuffixButton setEnabled: YES];
	}
	if ([aNotification object] == typesListDataBrowser || [aNotification object] == NULL)
	{
		selectedItems = [typesListDataBrowser selectedRowIndexes];
		for (i = 0; i < [typesList numTypes]; i++)
		{
			if ([selectedItems containsIndex: i])
				selected++;
		}
		
		//update button status
		if (selected == 0)
			[removeTypeButton setEnabled: NO];
		else
			[removeTypeButton setEnabled: YES];
	}
	if ([aNotification object] == profilesDataBrowser || [aNotification object] == NULL)//selection changed in Profile list
	{
		selectedItems = [profilesDataBrowser selectedRowIndexes];
		for (i = 0; i < [self numberOfRowsInTableView: profilesDataBrowser]; i++)
		{
			if ([selectedItems containsIndex: i])
				selected++;
		}
		
		//update button status
		if (selected == 0)
		{
			[removeProfileButton setEnabled: NO];
			[loadProfileButton setEnabled: NO];
		}
		else
		{
			[removeProfileButton setEnabled: YES];
			[loadProfileButton setEnabled: YES];
		}
	}
}


- (NSDragOperation)draggingEntered:(id <NSDraggingInfo>)sender 
{

    NSPasteboard *pboard;
    NSDragOperation sourceDragMask;

    sourceDragMask = [sender draggingSourceOperationMask];
    pboard = [sender draggingPasteboard];


    if ( [[pboard types] containsObject:NSFilenamesPboardType] ) 
	{
        if (sourceDragMask & NSDragOperationLink) 
            return NSDragOperationLink;
		else if (sourceDragMask & NSDragOperationCopy)
            return NSDragOperationCopy;
    }

    return NSDragOperationNone;
}

#pragma mark -



/*****************************************
 - Delegate for when text changes in any of the Platypus text fields
*****************************************/
- (void)controlTextDidChange:(NSNotification *)aNotification
{
	BOOL	isDir, exists = NO, validName = NO;
	
	//app name or script path was changed
	if ([aNotification object] == NULL || [aNotification object] == appNameTextField || [aNotification object] == scriptPathTextField)
	{
		if ([[appNameTextField stringValue] length] > 0)
			validName = YES;
		if ([[NSFileManager defaultManager] fileExistsAtPath: [scriptPathTextField stringValue] isDirectory:&isDir] && !isDir)
			exists = YES;
		
		//edit and reveal buttons -- and text coloring
		if (exists)
		{
			[scriptPathTextField setTextColor: [NSColor blackColor]];
			[editScriptButton setEnabled: YES];
			[revealScriptButton setEnabled: YES];
		}
		else
		{
			[scriptPathTextField setTextColor: [NSColor redColor]];
			[editScriptButton setEnabled: NO];
			[revealScriptButton setEnabled: NO];
		}
		
		//enable/disable create app button
		if (validName && exists)
			[createAppButton setEnabled: YES];
		else
			[createAppButton setEnabled: NO];
		
		//update identifier
		if (validName)
			[bundleIdentifierTextField setStringValue: [self generateBundleIdentifier]];
		else
			[bundleIdentifierTextField setStringValue: [[NSUserDefaults standardUserDefaults] objectForKey:@"DefaultBundleIdentifierPrefix"]];
	}
	
	//bundle signature or "type code" changed
	if ([aNotification object] == signatureTextField || [aNotification object] == typeCodeTextField || [aNotification object] == NULL)
	{
		NSRange	 range = { 0, 4 };
		NSString *sig = [[aNotification object] stringValue];
		
		if ([sig length] > 4)
		{
			[[aNotification object] setStringValue: [sig substringWithRange: range]];
		}
		else if ([sig length] < 4)
			[[aNotification object] setTextColor: [NSColor redColor]];
		else if ([sig length] == 4)
			[[aNotification object] setTextColor: [NSColor blackColor]];
	}
	
	//interpreter changed
	if ([aNotification object] == interpreterTextField || [aNotification object] == NULL)
	{
		if ([[NSFileManager defaultManager] fileExistsAtPath: [interpreterTextField stringValue] isDirectory:&isDir] && !isDir)
			[interpreterTextField setTextColor: [NSColor blackColor]];
		else
			[interpreterTextField setTextColor: [NSColor redColor]];
	}
	
	//enable/disable buttons for Edit Types window
	if ([aNotification object] == suffixTextField || [aNotification object] == typeCodeTextField || [aNotification object] == NULL)
	{
		if ([[suffixTextField stringValue] length] > 0)
			[addSuffixButton setEnabled: YES];
		else
			[addSuffixButton setEnabled: NO];
			
		if ([[typeCodeTextField stringValue] length] == 4)
			[addTypeButton setEnabled: YES];
		else
			[addTypeButton setEnabled: NO];
	}
}

/*****************************************
 - Delegate for enabling and disabling menu items
*****************************************/
- (BOOL)validateMenuItem:(NSMenuItem*)anItem 
{
	BOOL isDir;

	//edit script
	if ([[anItem title] isEqualToString:@"Edit Script"] && (![[NSFileManager defaultManager] fileExistsAtPath: [scriptPathTextField stringValue] isDirectory:&isDir] || isDir))
		return NO;
		
	//reveal script
	if ([[anItem title] isEqualToString:@"Reveal Script"] && (![[NSFileManager defaultManager] fileExistsAtPath: [scriptPathTextField stringValue] isDirectory:&isDir] || isDir))
		return NO;
		
	//run script
	if ([[anItem title] isEqualToString:@"Run Script in Terminal"] && (![[NSFileManager defaultManager] fileExistsAtPath: [scriptPathTextField stringValue] isDirectory:&isDir] || isDir))
		return NO;
	
	//check script syntax
	if ([[anItem title] isEqualToString:@"Check Script Syntax"] && (![[NSFileManager defaultManager] fileExistsAtPath: [scriptPathTextField stringValue] isDirectory:&isDir] || isDir))
		return NO;
	
	//create app menu
	if ([[anItem title] isEqualToString:@"Create App"] && (![[NSFileManager defaultManager] fileExistsAtPath: [scriptPathTextField stringValue] isDirectory:&isDir] || isDir))
		return NO;

	//File list menu items
	if ([[anItem title] isEqualToString:@"Add File To Bundle"] && [showAdvancedArrow state] == NSOffState)
		return NO;
	if ([[anItem title] isEqualToString:@"Clear File List"] && [showAdvancedArrow state] == NSOffState)
		return NO;
	
    if ([[anItem title] isEqualToString:@"Remove File"] && ([fileList numFiles] == 0 || [showAdvancedArrow state] == NSOffState || [fileList selectedRow] == -1))
	{
		return NO;
	}
	
    if ([[anItem title] isEqualToString:@"Reveal File In File List"] && ([fileList numFiles] == 0 || [showAdvancedArrow state] == NSOffState || [fileList selectedRow] == -1))
		return NO;
		
	if ([[anItem title] isEqualToString:@"Edit Types..."] && ![isDroppableCheckbox intValue])
		return NO;

	//Profiles menu
	if ([[anItem title] isEqualToString:@"Save Profile"] && ([[appNameTextField stringValue] length] == 0 ||[[scriptPathTextField stringValue] length] == 0))
		return NO;

	if ([[anItem title] isEqualToString:@"Clear All Profiles"] && ![[[NSUserDefaults standardUserDefaults] objectForKey:@"Profiles"] count])
		return NO;
			
	// Icon contextual menu
	//edit script
	if ([[anItem title] isEqualToString:@"Paste Icon"])
	{
		NSArray *types = [[NSPasteboard generalPasteboard] types];
		if ([types containsObject: NSPDFPboardType] || [types containsObject: NSPICTPboardType] || 
			[types containsObject: NSPostScriptPboardType] || [types containsObject: NSTIFFPboardType])
			return YES;
		else
			return NO;
	}
	
	// files list contextual menu
	if ([[anItem title] isEqualToString:@"Remove"] || [[anItem title] isEqualToString:@"Reveal In Finder"])
	{
		if ([fileList selectedRow] == -1)
			return NO;
		else
			return NO;
	}

    return YES;
}

/*****************************************
 - Load the script of item selected in Open Recent Menu
*****************************************/
-(void) openRecentMenuItemSelected: (id)sender
{
	BOOL	isDir = NO;

	if ([[NSFileManager defaultManager] fileExistsAtPath: [sender title] isDirectory: &isDir] && isDir == NO)
		[self loadScript: [sender title]];
	else
		[STUtil alert:@"Invalid item" subText: @"The file you selected no longer exists at the specified path."];
}
/*****************************************
 - Generate the Open Recent Menu
*****************************************/
-(void) constructOpenRecentMenu
{
	int i;

	//clear out all menu itesm
	while ([openRecentMenu numberOfItems])
		[openRecentMenu removeItemAtIndex: 0];

	if ([recentItems count] > 0)
	{
		//populate with contents of array
		for (i = [recentItems count]-1; i >= 0 ; i--)
		{
			[openRecentMenu addItemWithTitle: [recentItems objectAtIndex: i] action: @selector(openRecentMenuItemSelected:) keyEquivalent:@""];
		}
		
		//add seperator and clear menu
		[openRecentMenu addItem: [NSMenuItem separatorItem]];
		[openRecentMenu addItemWithTitle: @"Clear" action: @selector(clearRecentItems) keyEquivalent:@""];
		
	}
	else
	{
		[openRecentMenu addItemWithTitle: @"Empty" action: NULL keyEquivalent:@""];
		[[openRecentMenu itemAtIndex: 0] setEnabled: NO];
	}
}
/*****************************************
 - Clear the Recent Items menu
*****************************************/
-(void) clearRecentItems
{
	[recentItems removeAllObjects];
	[self constructOpenRecentMenu];
}

#pragma mark -

- (IBAction)loadProfile:(id)sender
{
	int i;
	NSIndexSet *selectedItems = [profilesDataBrowser selectedRowIndexes];
	
	for (i = 0; i < [self numberOfRowsInTableView: profilesDataBrowser]; i++)
	{
		//if selected in list, we load it
		if ([selectedItems containsIndex: i])
		{
			[self profileMenuItemSelected: [profilesMenu itemAtIndex: i+4]];
			[self closeEditProfilesSheet: self];
		}
	}
}

/*****************************************
 - Save a profile with values from fields
*****************************************/
- (IBAction) saveProfile:(id)sender;
{
	if (![self verifyFieldContents])//are there invalid values in the fields?
		return;
	
	NSDictionary *profileDict = [NSDictionary dictionaryWithObjectsAndKeys:
					[appNameTextField stringValue], @"AppName",
					[scriptPathTextField stringValue], @"ScriptPath",
					[NSNumber numberWithInt: [[outputTypeRadioButtons selectedCell] tag]], @"OutputType",
					[NSNumber numberWithInt: [[scriptTypeRadioButtons selectedCell] tag]], @"ScriptType",
					[[iconControl getImage] TIFFRepresentation], @"AppIcon",
					[interpreterTextField stringValue], @"Interpreter",
					[versionTextField stringValue], @"Version",
					[signatureTextField stringValue], @"Signature",
					[bundleIdentifierTextField stringValue], @"BundleIdentifier",
					[authorTextField stringValue], @"Author",
					[NSNumber numberWithBool: [rootPrivilegesCheckbox intValue]], @"RequiresAdminPrivileges",
					[NSNumber numberWithBool: [encryptCheckbox intValue]], @"EncryptAndChecksum",
					[NSNumber numberWithBool: [isDroppableCheckbox intValue]], @"IsDroppable",
					[NSNumber numberWithBool: [showInDockCheckbox intValue]], @"RunsInBackground",
					[NSNumber numberWithBool: [remainRunningCheckbox intValue]], @"RemainRunningAfterCompletion",
					[fileList getFilesArray], @"BundledFiles",
					[typesList getTypesArray], @"Types",
					[suffixList getSuffixArray], @"Suffixes",
					[NSNumber numberWithInt: [[appFunctionRadioButtons selectedCell] tag]], @"AppFunction", nil];
	
	NSMutableArray *profiles = [NSMutableArray arrayWithCapacity: 255];
	[profiles addObjectsFromArray: [[NSUserDefaults standardUserDefaults] objectForKey:@"Profiles"]];
	[profiles addObject: profileDict];
	[[NSUserDefaults standardUserDefaults] setObject: profiles  forKey:@"Profiles"];
	//regenerate Profiles menu
	[self constructProfilesMenu];
	
	//update data browser
	[profilesDataBrowser setDataSource: self];
	[profilesDataBrowser reloadData];
}


/*****************************************
 - Fill Platypus fields in with data from profile when it's selected
*****************************************/
-(void) profileMenuItemSelected: (id)sender
{
	int				itemNum = [profilesMenu indexOfItem: sender] - 4;
	NSDictionary	*profile = [[[NSUserDefaults standardUserDefaults] objectForKey:@"Profiles"] objectAtIndex: itemNum];
	NSImage			*appIcon;
	
	//text fields
	[appNameTextField setStringValue: [profile objectForKey: @"AppName"]];
	[scriptPathTextField setStringValue: [profile objectForKey: @"ScriptPath"]];
	
	[versionTextField setStringValue: [profile objectForKey: @"Version"]];
	[signatureTextField setStringValue: [profile objectForKey: @"Signature"]];

		//must check if author and bundle identifier are valid, since older versions of Platypus did not keep this
	if ([profile objectForKey: @"BundleIdentifier"] == NULL)
		[bundleIdentifierTextField setStringValue: [self generateBundleIdentifier]];
	else
		[bundleIdentifierTextField setStringValue: [profile objectForKey: @"BundleIdentifier"]];
	
	if ([profile objectForKey: @"Author"] == NULL)
		[authorTextField setStringValue: [[NSUserDefaults standardUserDefaults] stringForKey:@"DefaultAuthor"]];
	else
		[authorTextField setStringValue: [profile objectForKey: @"Author"]];
	

	//radio buttons
		//set output type
		[outputTypeRadioButtons selectCellWithTag: [[profile objectForKey: @"OutputType"] intValue]];
		//[self outputTypeChanged: outputTypeRadioButtons];
		[self setScriptType: [[profile objectForKey: @"ScriptType"] intValue]];//script type
		[interpreterTextField setStringValue: [profile objectForKey: @"Interpreter"]];

	//icon
	// We need to be sure there is actual an icon value
	// There wouldn't be one in Profiles created in Platypus 2.5-2.6
	if ([profile objectForKey: @"AppIcon"] != NULL)
	{
		appIcon = [[[NSImage alloc] initWithData: [profile objectForKey: @"AppIcon"]] autorelease];
		[iconControl setImage: appIcon];
	}
	
	//checkboxes
	[rootPrivilegesCheckbox setIntValue: [[profile objectForKey: @"RequiresAdminPrivileges"] boolValue]];
	[isDroppableCheckbox setIntValue: [[profile objectForKey: @"IsDroppable"] boolValue]];
		[self isDroppableWasClicked: isDroppableCheckbox];
	[encryptCheckbox setIntValue: [[profile objectForKey: @"EncryptAndChecksum"] boolValue]];
	[showInDockCheckbox setIntValue: [[profile objectForKey: @"RunsInBackground"] boolValue]];
	[remainRunningCheckbox setIntValue: [[profile objectForKey: @"RemainRunningAfterCompletion"] boolValue]];
	
	//file list
		[fileList clearList];
		[fileList addFiles: [profile objectForKey: @"BundledFiles"]];

		//update button status
		[self tableViewSelectionDidChange: NULL];
	
	//suffix list
		[suffixList clearList];
		[suffixList addSuffixes: [profile objectForKey: @"Suffixes"]];
		[suffixListDataBrowser setDataSource: suffixList];
		[suffixListDataBrowser reloadData];
	
		if ([suffixList hasAllSuffixes])
			[numSuffixesTextField setStringValue: @"All suffixes"];
		else
			[numSuffixesTextField setStringValue: [NSString stringWithFormat:@"%d suffixes", [suffixList numSuffixes]]];
			
	//types list
		[typesList clearList];
		[typesList addTypes: [profile objectForKey: @"Types"]];
		[typesListDataBrowser setDataSource: typesList];
		[typesListDataBrowser reloadData];
		
		if ([typesList hasAllTypes])
			[numTypesTextField setStringValue: @"All file types"];
		else
			[numTypesTextField setStringValue: [NSString stringWithFormat:@"%d file types", [typesList numTypes]]];
		if ([typesList hasFolderType])
			[numTypesTextField setStringValue: [[numTypesTextField stringValue] stringByAppendingString: @" and folders"]];
	//set app function
		[appFunctionRadioButtons selectCellWithTag: [[profile objectForKey: @"AppFunction"] intValue]];
	
	//update buttons
	[self controlTextDidChange: NULL];
}

/*****************************************
 - Remove selected profile
*****************************************/
- (IBAction) removeProfile:(id)sender
{
	int i, didRemove = FALSE;
	NSIndexSet *selectedItems = [profilesDataBrowser selectedRowIndexes];
	NSMutableArray *profilesArray = [NSMutableArray arrayWithCapacity: 255];
	
	//create a new array
	[profilesArray addObjectsFromArray: [[NSUserDefaults standardUserDefaults] objectForKey:@"Profiles"]];
	
	for (i = [self numberOfRowsInTableView: profilesDataBrowser]; i >= 0; i--)
	{
		//remove all the selected item indexes from the new array
		if ([selectedItems containsIndex: i])
		{
			[profilesArray removeObjectAtIndex: i];
			didRemove = TRUE;
		}
	}
	
	if (didRemove == TRUE)
	{
		//make the new array our profiles in prefs
		[[NSUserDefaults standardUserDefaults] setObject: profilesArray forKey:@"Profiles"];
		[profilesDataBrowser reloadData];
		[self constructProfilesMenu];
	}
}
/*****************************************
 - Clear the profiles list
*****************************************/
- (IBAction) clearAllProfiles:(id)sender
{
	//clear the array with the profiles data
	[[NSUserDefaults standardUserDefaults] setObject: [NSArray array]  forKey:@"Profiles"];
	//regenerate the menu
	[self constructProfilesMenu];
	
	//update data browser
	[profilesDataBrowser setDataSource: self];
	[profilesDataBrowser reloadData];
}

/*****************************************
 - Generate the Profiles menu according to the save profiles
*****************************************/
- (void) constructProfilesMenu
{
	int i;
	NSArray *profiles = [[NSUserDefaults standardUserDefaults] objectForKey:@"Profiles"];

	//clear out all menu itesm
	while ([profilesMenu numberOfItems] > 4)
		[profilesMenu removeItemAtIndex: 4];

	if ([profiles count] > 0)
	{
		//populate with contents of array
		for (i = 0; i < [profiles count]; i++)
		{
			NSString	*menuItemTitle = [NSString stringWithFormat: @"%@ (%@)", [[profiles objectAtIndex: i] objectForKey: @"AppName"], [[profiles objectAtIndex: i] objectForKey: @"ScriptPath"]];
			[profilesMenu addItemWithTitle: menuItemTitle action: @selector(profileMenuItemSelected:) keyEquivalent:@""];
		}
	}
	else
	{
		[profilesMenu addItemWithTitle: @"Empty" action: NULL keyEquivalent:@""];
	}
}


/*****************************************
 - Display the Edit Profiles Window as a sheet
*****************************************/
- (IBAction) editProfiles: (id)sender
{
	[window setTitle: @"Platypus - Edit Profiles"];

	//update data browser
	[profilesDataBrowser setDataSource: self];
	[profilesDataBrowser reloadData];
	[self tableViewSelectionDidChange: NULL];

	//open window
	[NSApp beginSheet:	profilesWindow
						modalForWindow: window 
						modalDelegate:nil
						didEndSelector:nil
						contextInfo:nil];

	 [NSApp runModalForWindow: profilesWindow];
	 
	 [NSApp endSheet: profilesWindow];
     [profilesWindow orderOut:self];

}

- (IBAction)closeEditProfilesSheet:(id)sender
{
	[window setTitle: @"Platypus"];
	[NSApp stopModal];
}

- (int)numberOfRowsInTableView:(NSTableView *)aTableView
{
	return([[[NSUserDefaults standardUserDefaults] objectForKey:@"Profiles"] count]);
}

- (id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(int)rowIndex
{
	NSArray *profiles = [[NSUserDefaults standardUserDefaults] objectForKey:@"Profiles"];
	return([[profiles objectAtIndex: rowIndex] objectForKey: @"AppName"]);
	return(@"");
}

#pragma mark -

/*****************************************
 - Display the Edit Types Window as a sheet
*****************************************/
- (IBAction) openTypesSheet: (id)sender
{
	[window setTitle: @"Platypus - Edit Types"];
	//clear text fields from last time
	[typeCodeTextField setStringValue: @""];
	[suffixTextField setStringValue: @""];
	//open window
	[NSApp beginSheet:	typesWindow
						modalForWindow: window 
						modalDelegate:nil
						didEndSelector:nil
						contextInfo:nil];

	 [NSApp runModalForWindow: typesWindow];
	 
	 [NSApp endSheet:typesWindow];
     [typesWindow orderOut:self];
}

- (IBAction)closeTypesSheet:(id)sender
{
	//make sure typeslist contains valid values
	if ([typesList numTypes] <= 0)
	{
		[typesErrorTextField setStringValue: @"The Types list must contain at least one entry."];
		return;
	}
	else
	{
		[typesErrorTextField setStringValue: @""];
		[window setTitle: @"Platypus"];
		[NSApp stopModal];
	}
}

/*****************************************
 - called when [+] button is pressed in Types List
*****************************************/

- (IBAction) addType:(id)sender;
{
	//make sure the type is 4 characters long
	if ([[typeCodeTextField stringValue] length] != 4)
	{
				[STUtil sheetAlert:@"Invalid File Type" subText: @"A File Type must consist of exactly 4 ASCII characters." forWindow: typesWindow];
		return;
	}

	if (![typesList hasType: [typeCodeTextField stringValue]] && ([[typeCodeTextField stringValue] length] > 0))
	{
		[typesList addType: [typeCodeTextField stringValue]];
		[typeCodeTextField setStringValue: @""];
	}
	//update
	[typesListDataBrowser setDataSource: typesList];
	[typesListDataBrowser reloadData];
	
	if ([typesList hasAllTypes])
		[numTypesTextField setStringValue: @"All file types"];
	else
		[numTypesTextField setStringValue: [NSString stringWithFormat:@"%d file types", [typesList numTypes]]];
	if ([typesList hasFolderType])
		[numTypesTextField setStringValue: [[numTypesTextField stringValue] stringByAppendingString: @" and folders"]];
}

/*****************************************
 - called when [-] button is pressed in Types List
*****************************************/

- (IBAction) removeType:(id)sender;
{
	int i;
	NSIndexSet *selectedItems = [typesListDataBrowser selectedRowIndexes];
	
	for (i = [typesList numTypes]; i >= 0; i--)
	{
		if ([selectedItems containsIndex: i])
		{
			[typesList removeType: i];
			[typesListDataBrowser reloadData];
			break;
		}
	}
	
	if ([typesList hasAllTypes])
		[numTypesTextField setStringValue: @"All file types"];
	else
		[numTypesTextField setStringValue: [NSString stringWithFormat:@"%d file types", [typesList numTypes]]];
	if ([typesList hasFolderType])
		[numTypesTextField setStringValue: [[numTypesTextField stringValue] stringByAppendingString: @" and folders"]];
}

/*****************************************
 - called when [C] button is pressed in Types List
*****************************************/
- (IBAction) clearTypesList:(id)sender
{
	[typesList clearList];
	[typesListDataBrowser reloadData];
	[numTypesTextField setStringValue: [NSString stringWithFormat:@"%d file types", [typesList numTypes]]];
}

/*****************************************
 - called when [+] button is pressed in Types List
*****************************************/

- (IBAction) addSuffix:(id)sender;
{
	NSString	*theSuffix = [suffixTextField stringValue];
	
	if ([suffixList hasSuffix: theSuffix] || ([theSuffix length] < 0))
		return;
		
	//if the user put in a suffix beginning with a '.', we trim the string to start from index 1
	if ([theSuffix characterAtIndex: 0] == '.')
		theSuffix = [theSuffix substringFromIndex: 1];

	[suffixList addSuffix: theSuffix];
	[suffixTextField setStringValue: @""];

	//update
	[suffixListDataBrowser setDataSource: suffixList];
	[suffixListDataBrowser reloadData];
	
	if ([suffixList hasAllSuffixes])
		[numSuffixesTextField setStringValue: @"All suffixes"];
	else
		[numSuffixesTextField setStringValue: [NSString stringWithFormat:@"%d suffixes", [suffixList numSuffixes]]];
}

/*****************************************
 - called when [-] button is pressed in Types List
*****************************************/

- (IBAction) removeSuffix:(id)sender;
{
	int i;
	NSIndexSet *selectedItems = [suffixListDataBrowser selectedRowIndexes];
	
	for (i = [suffixList numSuffixes]; i >= 0; i--)
	{
		if ([selectedItems containsIndex: i])
		{
			[suffixList removeSuffix: i];
			[suffixListDataBrowser reloadData];
			break;
		}
	}
	
	if ([suffixList hasAllSuffixes])
		[numSuffixesTextField setStringValue: @"All suffixes"];
	else
		[numSuffixesTextField setStringValue: [NSString stringWithFormat:@"%d suffixes", [suffixList numSuffixes]]];
}

/*****************************************
 - called when [C] button is pressed in Types List
*****************************************/
- (IBAction) clearSuffixList:(id)sender
{
	[suffixList clearList];
	[suffixListDataBrowser reloadData];
	[numSuffixesTextField setStringValue: [NSString stringWithFormat:@"%d suffixes", [suffixList numSuffixes]]];
}



/*****************************************
 - called when "Default" button is pressed in Types List
*****************************************/
- (IBAction) setDefaultTypes:(id)sender
{
	//default File Types
	[typesList clearList];
	[typesList addType: @"****"];
	[typesList addType: @"fold"];
	[typesListDataBrowser reloadData];
	
		if ([typesList hasAllTypes])
		[numTypesTextField setStringValue: @"All file types"];
	else
		[numTypesTextField setStringValue: [NSString stringWithFormat:@"%d file types", [typesList numTypes]]];
	if ([typesList hasFolderType])
		[numTypesTextField setStringValue: [[numTypesTextField stringValue] stringByAppendingString: @" and folders"]];
		
	//default suffixes
	[suffixList clearList];
	[suffixList addSuffix: @"*"];
	[suffixListDataBrowser reloadData];
	
	if ([suffixList hasAllSuffixes])
		[numSuffixesTextField setStringValue: @"All suffixes"];
	else
		[numSuffixesTextField setStringValue: [NSString stringWithFormat:@"%d suffixes", [suffixList numSuffixes]]];
	
	//set app function to default
	[appFunctionRadioButtons selectCellWithTag: 0];
}

#pragma mark -

- (void)openScriptInBuiltInEditor: (NSString *)path
{
	[editorText setFont:[NSFont userFixedPitchFontOfSize: 10.0]]; //set monospace font
	
	//update text notifying user of the path to the script he is editing
	[editorScriptPath setStringValue: [NSString stringWithFormat: @"Editing script at path %@", path]];
	[editorText setString: [NSString stringWithContentsOfFile: path]];

	[window setTitle: @"Platypus Built-In Script Editor"];
	[NSApp beginSheet:	editorWindow
						modalForWindow: window 
						modalDelegate:nil
						didEndSelector:nil
						contextInfo:nil];
	[NSApp runModalForWindow: editorWindow];
	[NSApp endSheet: editorWindow];
    [editorWindow orderOut:self];

	
}

- (IBAction)editorSave: (id)sender
{
	//see if the file in question exists and we can write it
    if (access([[scriptPathTextField stringValue] cString], R_OK|W_OK|F_OK) == -1)
        [STUtil alert: @"Unable to save changes" subText: @"You don't the neccesary privileges to modify this text file."];
	else //save it
		[[editorText string] writeToFile: [scriptPathTextField stringValue] atomically: YES];

	[window setTitle: @"Platypus"];
	[NSApp stopModal];
}

- (IBAction)editorCancel: (id)sender
{
	[window setTitle: @"Platypus"];
	[NSApp stopModal];
}

- (IBAction)editorCheckSyntax: (id)sender
{
	[self checkSyntaxOfScript: self];
}



#pragma mark -

/*****************************************
 - Open Platypus Help HTML file within app bundle
*****************************************/
- (IBAction) showHelp:(id)sender
{
	NSURL *appURL = nil;
    OSStatus err = LSGetApplicationForURL((CFURLRef)[NSURL URLWithString:@"http:"], kLSRolesAll, NULL, (CFURLRef *)&appURL);
	if (err != noErr)
		return;
	else
		[[NSWorkspace sharedWorkspace] openFile: [[NSBundle mainBundle] pathForResource:@"index.html" ofType:nil] withApplication: [appURL path]];
}

/*****************************************
 - Open 'platypus' command line tool man page in PDF
*****************************************/
- (IBAction) showManPage:(id)sender
{	
	[[NSWorkspace sharedWorkspace] openFile: [[NSBundle mainBundle] pathForResource:@"platypus.man.pdf" ofType:nil]];
}

/*****************************************
 - Open Readme file
*****************************************/
- (IBAction) showReadme:(id)sender
{	
		NSURL *appURL = nil;
    OSStatus err = LSGetApplicationForURL((CFURLRef)[NSURL URLWithString:@"http:"], kLSRolesAll, NULL, (CFURLRef *)&appURL);
	if (err != noErr)
		return;
	else
		[[NSWorkspace sharedWorkspace] openFile: [[NSBundle mainBundle] pathForResource:@"Readme.html" ofType:nil] withApplication: [appURL path]];

}
@end
