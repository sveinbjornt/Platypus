/* SEController */

#import <Cocoa/Cocoa.h>
#import "SillyStringEncrypt.h"
#import "STChecksum.h"

@interface SEController : NSObject
{
    IBOutlet id checksumTextField;
    IBOutlet id clearText;
    IBOutlet id encryptText;
}
- (IBAction)encrypt:(id)sender;
@end
