#import "SEController.h"

@implementation SEController

- (IBAction)encrypt:(id)sender
{
	NSString *clearStr = [clearText string];
	[encryptText setString: [SillyStringEncrypt sillyEncryptString: clearStr]];


	[clearStr writeToFile: @"/tmp/scriptEncryptChecksumTestFile" atomically: YES];
	[checksumTextField setStringValue: [STChecksum getChecksumForFileAsString:  @"/tmp/scriptEncryptChecksumTestFile"]];
	
}

@end
