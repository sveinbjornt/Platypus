/* EnvController */

#import <Cocoa/Cocoa.h>

@interface EnvController : NSObject
{
    IBOutlet id envTableView;
    IBOutlet id envWindow;
	IBOutlet id window;
	
	IBOutlet id addButton;
	IBOutlet id removeButton;
	IBOutlet id clearButton;
	
	NSMutableArray	*keys;
	NSMutableArray	*values;
}
- (IBAction)add:(id)sender;
- (IBAction)apply:(id)sender;
- (IBAction)clear:(id)sender;
- (IBAction)help:(id)sender;
- (IBAction)remove:(id)sender;
- (IBAction)resetDefaults:(id)sender;
- (IBAction)show:(id)sender;
- (NSMutableDictionary *)environmentDictionary;
@end
