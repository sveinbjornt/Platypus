/*
    ScriptExec - binary bundled into Platypus-created applications
    Copyright (C) 2003-2009 Sveinbjorn Thordarson <sveinbjornt@simnet.is>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#import "ScriptExecController.h"

@implementation ScriptExecController

- (id)init
{
	if ((self = [super init])) 
	{
		arguments = [[NSMutableArray alloc] initWithCapacity: ARG_MAX];
		fileArgs = [[NSMutableArray alloc] initWithCapacity: ARG_MAX];
		textEncoding = NSASCIIStringEncoding;
    }
    return self;
}

-(void)awakeFromNib
{
	// default to this
	outputTextView = textOutputTextField;
}

-(void)dealloc
{
	if (arguments != NULL) { [arguments release]; }
	if (fileArgs != NULL)  { [fileArgs release];  }
	
	[super dealloc];
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
	//load settings from app bundle
	[self loadSettings];
		
	//put application name into the relevant menu items
	[quitMenuItem setTitle: [NSString stringWithFormat: @"Quit %@", appName]];
	[aboutMenuItem setTitle: [NSString stringWithFormat: @"About %@", appName]];
	[hideMenuItem setTitle: [NSString stringWithFormat: @"Hide %@", appName]];
	
	// register windows to receive dragged files if apps is set to be droppable
	if (isDroppable)
	{
		[progressBarWindow registerForDraggedTypes: [NSArray arrayWithObjects:NSFilenamesPboardType, nil]];
		[textOutputWindow registerForDraggedTypes: [NSArray arrayWithObjects:NSFilenamesPboardType, nil]];
	}
	
	//prepare controls etc. for different output types
	if (outputType == kProgressBarOutput)
	{
		// add menu item for Show Details
		[[windowMenu insertItemWithTitle: @"Toggle Details" action: @selector(performClick:)  keyEquivalent:@"T" atIndex: 2] setTarget: progressBarDetailsTriangle];
		[windowMenu insertItem: [NSMenuItem separatorItem] atIndex: 2];
		
		// style the text field
		outputTextView = progressBarTextField;
		[outputTextView setFont: textFont];
		[outputTextView setTextColor: textForeground];
		[outputTextView setBackgroundColor: textBackground];
		[outputTextView setString: @"Running...\n"]; // for some reason this is needed to apply the style -- bug somewhere?		
		
		// fire off progress indicator
		[progressBarIndicator setUsesThreadedAnimation: YES];
		
		//preare window
		[progressBarWindow setTitle: appName];
		[progressBarWindow center];
		[progressBarWindow makeKeyAndOrderFront: self];
	}
	else if (outputType == kTextOutput)
	{   
		// style the text field
		outputTextView = textOutputTextField;
		[outputTextView setFont: textFont];
		[outputTextView setTextColor: textForeground];
		[outputTextView setBackgroundColor: textBackground];
		[outputTextView setString: @"Running...\n"]; // for some reason this is needed to apply the style -- bug somewhere?
		
		// fire off progress indicator
		[textOutputProgressIndicator setUsesThreadedAnimation: YES];
		
		// prepare window
		[textOutputWindow setTitle: appName];
		[textOutputWindow center];
		[textOutputWindow makeKeyAndOrderFront: self];
	}
	else if (outputType == kWebOutput)
	{
		// fire off progress indicator
		[webOutputProgressIndicator setUsesThreadedAnimation: YES];
		
		// prepare window
		[webOutputWindow setTitle: appName];
		[webOutputWindow center];
		[webOutputWindow makeKeyAndOrderFront: self];		
	}
	
	NSLog(@"Application did finish launching.  Now about to execute script");
	[self executeScript];
}

#pragma mark -

//
// set up controls, construct arguments list etc.
// before actually running the script
//
- (void)prepareForExecution
{
	NSLog(@"Preparing for execution");
	
	//[outputTextView setString: @" "];
	
	// set all the progress indicators off
	if (outputType == kProgressBarOutput)
	{
		//prepare progress bar
		[progressBarIndicator setIndeterminate: YES];
		[progressBarIndicator startAnimation: self];
		[progressBarMessageTextField setStringValue: @"Running..."];
	}
	else if (outputType == kTextOutput)
	{   
		[textOutputProgressIndicator startAnimation: self];
	}
	else if (outputType == kWebOutput)
	{
		[webOutputProgressIndicator startAnimation: self];
	}
	
	//clear arguments list and reconstruct it
	// clean these so they're ready for script execution
	[arguments removeAllObjects];
	
	// first, add all specified arguments for interpreter
	if ([paramsArray count] > 0)
		[arguments addObjectsFromArray: paramsArray];

	// add script as argument to interpreter
	if (secureScript)
		[arguments addObject: kTempScriptFile];
	else
		[arguments addObject: scriptPath];
	
	//set $1 as path of application bundle if that option is set
	if (appPathAsFirstArg)
		[arguments addObject: [[NSBundle mainBundle] bundlePath]]; 
	
	//finally, add any file arguments we may have received as dropped/opened
	if ([fileArgs count] > 0)
		[arguments addObjectsFromArray: fileArgs];
}

- (void)executeScript
{
	[self prepareForExecution];
	
	NSLog(@"About to execute script");
	//start new thread for executing script
	if (execStyle == kPrivilegedExecution) //Authentication mode
		[self executeScriptWithPrivileges];
	else //plain old regular
		[self executeScriptWithoutPrivileges];
}

#pragma mark -

//launch regular user task with NSTask
- (void)executeScriptWithoutPrivileges
{	
	//initalize task
	task = [[NSTask alloc] init];
	
	// we monitor output if TextWindow or web output
	//if (outputType == kTextOutput || outputType == kWebOutput)
	{
		outputPipe = [NSPipe pipe];
		[task setStandardOutput: outputPipe];
		[task setStandardError: outputPipe];
		readHandle = [outputPipe fileHandleForReading];
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getTextData:) name: NSFileHandleReadCompletionNotification object:readHandle];
		[readHandle readInBackgroundAndNotify];
	}

	//apply settings for task
	[task setLaunchPath: interpreter];
	[task setCurrentDirectoryPath: [[NSBundle mainBundle] resourcePath]];
	[task setArguments: arguments];
	
	//set it off
	[task launch];
	
	NSLog(@"Task launched");
	
	//set off timer that checks task status, i.e. when it's done 
	checkStatusTimer = [NSTimer scheduledTimerWithTimeInterval: 0.20 target: self selector:@selector(checkTaskStatus) userInfo: nil repeats: YES];
}

// check if task is running
- (void)checkTaskStatus
{
	if (![task isRunning])//if it's no longer running, we do clean up
	{
		[checkStatusTimer invalidate];
		[self taskFinished];
	}
}

#pragma mark -

//launch task with privileges using Authentication Manager
- (void)executeScriptWithPrivileges
{	
	OSErr					err = noErr;
    short					i;
	FILE					*outputFile;
	AuthorizationRef		authorizationRef;
	unsigned int			argumentsCount = [arguments count];
	char					*args[argumentsCount + 1];

	NSLog(@"Entering auth exec function");
	
	// construct an array of c strings from NSArray w. arguments
	for (i = 0; i < argumentsCount; i++) 
	{
		NSString *theString = [arguments objectAtIndex:i];
		unsigned int stringLength = [theString length];
		
		args[i] = malloc((stringLength + 1) * sizeof(char));
		snprintf(args[i], stringLength + 1, "%s", [theString UTF8String]);
	}
	args[argumentsCount] = NULL;
	
    NSLog(@"Finished creating arguments in auth exec function");
   
	// Use Apple's Authentication Manager APIs to get an Authorization Reference
	// This is not the Apple-recommended way of doing this -- but with setuid under attack etc, it'll just have to do
	// These Apple APIs are quite possibly the most horrible of the Mac OS X APIs
	// Also, the question remains whether we should use something other than an empty environment
	// A lot of people have reported problems with scripts because of unset environmental variables
	
    err = AuthorizationCreate(NULL, kAuthorizationEmptyEnvironment, kAuthorizationFlagDefaults, &authorizationRef);
    if (err != errAuthorizationSuccess)
	{
		NSLog(@"Authentication failed");
        [[NSApplication sharedApplication] terminate: self];
		return;
	}
		
	//use Authorization Reference to execute script with privileges
    if (!(err = AuthorizationExecuteWithPrivileges(authorizationRef, [interpreter fileSystemRepresentation], kAuthorizationFlagDefaults, args, &outputFile)) != noErr)
	{
		NSLog(@"Got authorization");
		
		for (i = 0; i < argumentsCount; i++)
			free(args[i]);
		
		//get NSFileHandle for the task output
		readHandle = [[NSFileHandle alloc] initWithFileDescriptor: fileno(outputFile) closeOnDealloc: YES];
		childPid = fcntl(fileno(outputFile), F_GETOWN, 0);//get pid
		
		// read the filehandle in the background and regularly print output into text window
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getTextData:) name:NSFileHandleReadCompletionNotification object:readHandle];
		[readHandle readInBackgroundAndNotify];
		checkStatusTimer = [NSTimer scheduledTimerWithTimeInterval: 0.20 target: self selector:@selector(checkPrivilegedTaskStatus) userInfo: nil repeats: YES];
		
		// destroy the auth ref
		//AuthorizationFree(authorizationRef, kAuthorizationFlagDefaults);
	}
	else
	{
		NSLog(@"Error %d occurred when attempting to run AuthorizationExecuteWithPrivileges. Terminating...", err);
		[[NSApplication sharedApplication] terminate: self];
	}
}

// check if privileged task is running
- (void)checkPrivilegedTaskStatus
{
    int ret, pid;
    pid = waitpid(childPid, &ret, WNOHANG);
    if (pid != 0)
	{
		[checkStatusTimer invalidate];
        [self taskFinished];
	}
}

#pragma mark -

// OK, called when task is finished.  Some cleaning up to do, controls need to be adjusted, etc.
- (void)taskFinished
{
		if (execStyle == kPrivilegedExecution)
		{
			[readHandle release];
			[[NSNotificationCenter defaultCenter] removeObserver: self];
		}
	
		//if we're using the "encrypted" script, we must remove the temporary clear-text one in /tmp/ if there is one
		if (secureScript && [[NSFileManager defaultManager] fileExistsAtPath: kTempScriptFile])
			[[NSFileManager defaultManager] removeFileAtPath: kTempScriptFile handler: nil];

		if (!remainRunning)
		{	
			// we quit if the app isn't set to continue running
			[[NSApplication sharedApplication] terminate: self];
		}
		else if (outputType == kTextOutput)
		{
			//update controls for text output window
			[textOutputCancelButton setTitle: @"Quit"];
			[textOutputCancelButton setKeyEquivalent:@"\r"];
			[textOutputProgressIndicator stopAnimation: self];
		}
		else if (outputType == kProgressBarOutput)
		{
			//update controls for progress bar output
			[progressBarMessageTextField setStringValue: @"Task completed"];
						
			// change progress bar
			[progressBarIndicator stopAnimation: self];
			[progressBarIndicator setIndeterminate: NO];
			[progressBarIndicator setDoubleValue: 100];
			
			// change button
			[progressBarCancelButton setTitle: @"Quit"];
			[progressBarCancelButton setKeyEquivalent:@"\r"];
		}
		else if (outputType == kWebOutput)
		{
			//update controls for web output window
			[webOutputCancelButton setTitle: @"Quit"];
			[webOutputCancelButton setKeyEquivalent:@"\r"];
			[webOutputProgressIndicator stopAnimation: self];
		}
	
	NSLog(@"Task finished");
}

//
//  read from the file handle and append it to the text window
//  we do this even
- (void) getTextData: (NSNotification *)aNotification
{
	//get the data
	NSData *data = [[aNotification userInfo] objectForKey:NSFileHandleNotificationDataItem];
	
	//make sure there's actual data
	if ([data length]) 
	{
		//append the output to the text field		
		[self appendOutput: data];
		
		// we schedule the file handle to go and read more data in the background again.
		[[aNotification object] readInBackgroundAndNotify];
	}
}

//
// this function receives all new data dumped out by the script and appends it to text field
// it is relatively memory efficient and doesn't leak, as far as I can tell...
//
- (void)appendOutput:(NSData *)data
{
	// we decode the script output according to specified character encoding
	NSString *outputString = [[[NSString alloc] initWithData: data encoding: textEncoding] autorelease];
	
	// if it's not just empty junk
	if (outputString)
	{
		// this is WAY faster than stringByAppendingString
		NSTextStorage *text = [outputTextView textStorage];
		[text replaceCharactersInRange:NSMakeRange([text length], 0) withString: outputString];
		
		// if web output, we continually re-render to accomodate incoming data, else we scroll down
		if (outputType == kWebOutput)
			[[webOutputWebView mainFrame] loadHTMLString: [outputTextView string] baseURL: [NSURL fileURLWithPath: [[NSBundle mainBundle] resourcePath]] ];
		else if (outputType == kTextOutput)
			[outputTextView scrollRangeToVisible: NSMakeRange([text length], 0)];
		else if (outputType == kProgressBarOutput)
		{			
			[outputTextView scrollRangeToVisible:NSMakeRange([text length], 0)];

			// progress bar is a bit different - we need to parse for complete lines of text to put in status text field
			NSString *wholeLine = [self getLastWholeNewlineOfOutput: [outputTextView string]];
			if ([wholeLine caseInsensitiveCompare: @""] != NSOrderedSame) // if the line is empty, we ignore it
			{
				if ([wholeLine hasPrefix: @"PROGRESS:"])
				{					
					NSString *progressPercent = [wholeLine substringFromIndex: 9];
					[progressBarIndicator setIndeterminate: NO];
					[progressBarIndicator setDoubleValue: [progressPercent doubleValue]];
				}
				else
					[progressBarMessageTextField setStringValue: wholeLine];
		
			}
		}
	}

}

// this function looks at a given string and extracts the latest
// whole newline, i.e. the last complete line of text
//
// we need this for dumping line output into the progress bar status text field
//
- (NSString *)getLastWholeNewlineOfOutput: (NSString *)str
{
	int		length = [str length];
	int		i;
	int		llstart = length;
	
	// first, find where the last line begins
	for (i = length-1; i >= 0; i--)
	{
		if (i == 0 || [str characterAtIndex: i-1] == '\n')
		{
			llstart = i;
			break;
		}
	}
	
	// get the line before the last line
	for (i = llstart-1; i >= 0; i--)
	{
		if (i == 0 || [str characterAtIndex: i-1] == '\n')
		{
			NSRange llRange = NSMakeRange(i, llstart-i);
			return [str substringWithRange: llRange];
		}
	}
	return @"";
}

#pragma mark -

// respond to AEOpenDoc -- so much more convenient than working with Apple Event Descriptors
- (void)application:(NSApplication *)theApplication openFiles:(NSArray *)filenames
{
	if (isDroppable)
	{
		NSLog(@"OpenFiles called: Adding files to arg");
		[fileArgs removeAllObjects];
		[fileArgs addObjectsFromArray: filenames];
		[self executeScript];
	}
}

- (NSApplicationTerminateReply)applicationShouldTerminate:(NSApplication *)sender
{	
	//terminate task
	if (task != NULL)
	{
		if ([task isRunning])
			[task terminate];
		[task release];
	}
	
	// just one more time, make sure we don't leave the clear-text script in the /tmp/ directory
	if ([[NSFileManager defaultManager] fileExistsAtPath: kTempScriptFile])
		[[NSFileManager defaultManager] removeFileAtPath: kTempScriptFile handler: nil];
	
	return(YES);
}

#pragma mark -

- (NSDragOperation)draggingEntered:(id <NSDraggingInfo>)sender 
{		
	if (isDroppable && [[[sender draggingPasteboard] types] containsObject:NSFilenamesPboardType] ) 
		return NSDragOperationLink;
    
	return NSDragOperationNone;
}


- (BOOL)performDragOperation:(id <NSDraggingInfo>)sender
{
	if (!isDroppable)
		return NO;
	
	NSPasteboard	*pboard = [sender draggingPasteboard];

    if ( [[pboard types] containsObject:NSFilenamesPboardType] ) 
	{
        NSArray *files = [pboard propertyListForType:NSFilenamesPboardType];
		[fileArgs removeAllObjects];
		[fileArgs addObjectsFromArray: files];
		return YES;
	}
	return NO;
}

- (void)concludeDragOperation:(id <NSDraggingInfo>)sender
{
	if (isDroppable)
		[self executeScript];
}

#pragma mark -

//load configuration files from application bundle
- (void)loadSettings
{
	NSBundle		*appBundle = [NSBundle mainBundle];
	NSFileManager   *fmgr = [NSFileManager defaultManager];
	NSDictionary	*appSettingsPlist;
	
	//make sure all the config files are present -- if not, we quit
	if (![fmgr fileExistsAtPath: [appBundle pathForResource:@"AppSettings.plist" ofType:nil]])
		[STUtil fatalAlert: @"Corrupted app bundle" subText: @"Vital configuration file missing from the application bundle."];
	
	//get app name
	appName = [[[appBundle executablePath] lastPathComponent] retain];
	
	//get dictionary with app settings
	appSettingsPlist = [NSDictionary dictionaryWithContentsOfFile: [appBundle pathForResource:@"AppSettings.plist" ofType:nil]];
	if (appSettingsPlist == NULL)
		[STUtil fatalAlert: @"Corrupted app settings" subText: @"The AppSettings.plist file for this application is corrupt."]; 
	
	//determine output type
	NSString *outputTypeStr = [appSettingsPlist objectForKey:@"OutputType"];
	if ([outputTypeStr isEqualToString: @"Progress Bar"])
		outputType = kProgressBarOutput;
	else if ([outputTypeStr isEqualToString: @"Text Window"])
		outputType = kTextOutput;
	else if ([outputTypeStr isEqualToString: @"Web View"])
		outputType = kWebOutput;
	else // we treat any other output mode as "None"
		outputType = kNoOutput;
	
	// we need some additional info from AppSettings.plist if we are presenting textual output
	if (outputType == kProgressBarOutput || outputType == kTextOutput)
	{
		//make sure all this data is sane 
		
		// font and size
		if ([appSettingsPlist objectForKey:@"TextFont"] != NULL || [appSettingsPlist objectForKey:@"TextSize"] != NULL)
			textFont = [NSFont fontWithName: DEFAULT_OUTPUT_FONT size: DEFAULT_OUTPUT_FONTSIZE];
		if (textFont == NULL);
			textFont = [NSFont fontWithName: [appSettingsPlist objectForKey:@"TextFont"] size: [[appSettingsPlist objectForKey:@"TextSize"] floatValue]];
			
		// foreground
		if ([appSettingsPlist objectForKey:@"TextForeground"] == NULL)
			textForeground = [STUtil colorFromHex: DEFAULT_OUTPUT_FG_COLOR];
		if (textForeground == NULL)
			textForeground	= [STUtil colorFromHex: [appSettingsPlist objectForKey:@"TextForeground"]];
		
		// background
		if ([appSettingsPlist objectForKey:@"TextBackground"] == NULL)
			textBackground = [STUtil colorFromHex: DEFAULT_OUTPUT_BG_COLOR];
		if (textBackground == NULL)
			textBackground	= [STUtil colorFromHex:  [appSettingsPlist objectForKey:@"TextBackground"]];
			
		// encoding
		if (textEncoding < 1)
			textEncoding = NSASCIIStringEncoding;
		else
			textEncoding	= (int)[[appSettingsPlist objectForKey:@"TextEncoding"] intValue];
	}
		
	//arguments to interpreter
	paramsArray = [[NSArray arrayWithArray: [appSettingsPlist objectForKey:@"InterpreterParams"]] retain];
	
	//pass app path as first arg?
	appPathAsFirstArg = [[appSettingsPlist objectForKey:@"AppPathAsFirstArg"] boolValue];
	
	//determine execution style
	execStyle = [[appSettingsPlist objectForKey:@"RequiresAdminPrivileges"] boolValue];

	//remain running?
	remainRunning = [[appSettingsPlist objectForKey:@"RemainRunningAfterCompletion"] boolValue];
	
	//is script encrypted and checksummed?
	secureScript = [[appSettingsPlist objectForKey: @"Secure"] boolValue];
	
	//can the app receive dropped files as args?
	isDroppable = [[appSettingsPlist objectForKey: @"IsDroppable"] boolValue];
		
	//get interpreter
	interpreter = [[NSString stringWithString: [appSettingsPlist objectForKey:@"ScriptInterpreter"]] retain];
	
	//if the script is not "secure" then we need a script file, otherwise we need data in appsettings.plist
	if ((!secureScript && ![fmgr fileExistsAtPath: [appBundle pathForResource:@"script" ofType: NULL]]) || (secureScript && [appSettingsPlist objectForKey:@"TextSettings"] == NULL))
		[STUtil fatalAlert: @"Corrupted app bundle" subText: @"Script missing from application bundle."];
	
	//get path to script
	scriptPath = [[NSString stringWithString: [appBundle pathForResource:@"script" ofType:nil]] retain];
	
	//if it is secured, we decode and write it to /tmp/
	if (secureScript)
	{
		// make sure we can write to /tmp/ -- you never know, eh?
		BOOL existsAtPath = [fmgr fileExistsAtPath: kTempScriptFile];
		
		if (![fmgr isWritableFileAtPath: TMP_PATH] || ([fmgr fileExistsAtPath: kTempScriptFile] && ![fmgr isWritableFileAtPath: TMP_PATH]))
			[STUtil fatalAlert: @"Unable to write temporary files" subText: [NSString stringWithFormat: @"Could not write to the %@ directory.  Make sure this directory exists and that you have write privileges.", TMP_PATH]]; 
		
		// remove file if it does exist and we have write privileges
		if (existsAtPath) {	[fmgr removeFileAtPath: kTempScriptFile handler: nil]; }
		
		// decode and write script
		NSString *b_str = [NSKeyedUnarchiver unarchiveObjectWithData: [appSettingsPlist objectForKey:@"TextSettings"]];
		NSData *sd = [NSData dataWithBytes: b_str length: [b_str length]];
		NSString *ss = [[NSString alloc] initWithData: sd encoding: NSASCIIStringEncoding];
		[ss writeToFile: kTempScriptFile atomically: YES];
		[ss release];
	}
}

// Respond to Cancel by exiting application
- (IBAction)cancel:(id)sender
{
	[[NSApplication sharedApplication] terminate: self];
}

// show / hide the details text field in progress bar output
- (IBAction)toggleDetails: (id)sender
{
	NSRect winRect = [progressBarWindow frame];
	
	if ([sender state] == NSOffState)
	{
		[progressBarWindow setShowsResizeIndicator: NO];
		winRect.origin.y += 224;
		winRect.size.height -= 224;		
		[progressBarWindow setFrame: winRect display: TRUE animate: TRUE];
	}
	else if ([sender state] == NSOnState)
	{
		[progressBarWindow setShowsResizeIndicator: YES];
		winRect.origin.y -= 224;
		winRect.size.height += 224;
		[progressBarWindow setFrame: winRect display: TRUE animate: TRUE];
	}
}

@end
