Platypus Command Line Tool Readme

The Platypus command line tool is the command line counterpart of the Platypus application.  It allows you to easily automate the creation of script applications (e.g. as part of a build process).  Please read the man page (either in the Terminal, or via the PDF version) for further information.