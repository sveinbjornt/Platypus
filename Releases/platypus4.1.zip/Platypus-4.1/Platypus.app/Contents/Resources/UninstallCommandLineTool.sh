#!/bin/sh

# UninstallCommandLineTool.sh
# Platypus
#
# Created by Sveinbjorn Thordarson on 6/17/08.
# Copyright (C) 2003-2009. All rights reserved.


# Delete resources
rm -R /usr/local/share/platypus/
rm /usr/local/bin/platypus
rm /usr/local/share/man/man1/platypus.1